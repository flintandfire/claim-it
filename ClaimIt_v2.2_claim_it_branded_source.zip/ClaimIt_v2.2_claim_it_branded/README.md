# Claim It 2.2 — Flint & Fire branded release candidate

Claim It is a privacy-first Android correspondence app. This release candidate applies the approved Claim It identity: bold white/pink Claim It lettering on a deep purple field with **Powered by Flint & Fire** beneath it. The Ghost can/fruit/drink branding is not used.

## Included
- Branded launch screen using the approved Claim It + Flint & Fire artwork
- Pastel pink/lilac/white screen palette
- My Letters with timestamps and delete support
- New Letter directory with interactive dial and category list
- Calendar date selection
- Android autofill hints for supported personal details
- Editable letter generation, copy, share and PDF export
- Assistance & Guidance
- About & Privacy panel
- WORTH-IT area reserved for the next feature pass
- Local-first storage; no server or AI API dependency

## Build
Open the `ClaimIt` folder in Android Studio and run the `app` debug configuration. The project targets Android 35 and requires the Android SDK/Gradle environment.

## Important
This source package is **not a signed production APK**. A release build still needs Android Studio/Gradle, physical-device QA, signing, store assets and final commercial/privacy pages.
