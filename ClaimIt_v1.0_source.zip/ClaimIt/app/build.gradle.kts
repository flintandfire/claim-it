plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.claimit"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.claimit"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "1.0"
    }
}
