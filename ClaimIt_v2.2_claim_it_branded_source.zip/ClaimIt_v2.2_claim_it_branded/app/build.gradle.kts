plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.claimit"
    compileSdk = 35
    defaultConfig { applicationId = "com.claimit"; minSdk = 26; targetSdk = 35; versionCode = 23; versionName = "2.3.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
