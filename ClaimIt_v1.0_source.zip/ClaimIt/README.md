# Claim It

First standalone Android prototype.

Goal: a free utility that helps users turn a rough description of a problem into a clear complaint/request letter.

Current v0.1:
- category picker
- free-form description
- deterministic local letter generator
- copy-to-clipboard
- no account
- no server
- no AI API
- no network permission

Commercial roadmap:
- more high-intent templates
- guided questions per category
- stronger consumer-rights wording without pretending to provide legal advice
- save/export/share
- privacy-first design
- carefully placed advertising
- store assets
- signed release APK
- Aptoide submission

Important: legal/benefits/medical content must be carefully scoped and reviewed before release; the app should generate general-purpose correspondence, not claim to provide professional legal advice.
