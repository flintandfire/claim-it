# Claim It — v1.0

Source-level v1.0 candidate is prepared.

Completed:
- guided workflows
- local personal details
- editable/copy/share letters
- saved history with individual load/delete
- PDF export
- first-launch onboarding
- About & Privacy panel
- commercial ad position reserved
- no server/API dependency

Release blockers:
- Android SDK/build environment
- signed APK generation
- physical-device QA
- final branding/store assets
- privacy/support web pages
- ad SDK + consent implementation
- Aptoide submission
