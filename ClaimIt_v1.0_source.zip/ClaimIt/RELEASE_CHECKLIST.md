# Claim It — v1.0 release candidate checklist

Source-level product features:
- guided category-specific correspondence
- reusable local sender/contact details
- editable letters
- copy/share
- saved letters/history
- individual history load/delete
- PDF export
- first-launch explanation
- About & Privacy explanation
- local-only operation with no API dependency
- ad placement reserved but ad SDK not yet integrated

Before public release:
- build and install signed APK
- test on physical Android devices
- verify PDF/share/history on Android versions supported
- create final icon/screenshots
- publish privacy policy/support page
- implement compliant ad SDK + consent where required
- test ad frequency and placement
- final security/privacy review
- Aptoide developer verification/submission
