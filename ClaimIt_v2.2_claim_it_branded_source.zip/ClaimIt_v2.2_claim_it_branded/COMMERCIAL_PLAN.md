# Claim It — commercial build notes

The product is now designed around:
1. Free utility with immediate result.
2. Local processing so ordinary use has near-zero infrastructure cost.
3. Repeat use through saved details/history.
4. Export/share so the result is useful outside the app.
5. Advertising as the initial monetisation route.

Advertising is not yet wired to an SDK. Before doing that we need a real Android build/test cycle so ad placement, consent requirements and crashes can be tested properly.

Recommended first ad position:
- a small banner/native slot below the primary workflow and above the legal/disclaimer text.
- avoid ads interrupting letter creation.
- avoid misleading ads that resemble the app's buttons.

Do not market the app as legal advice. It is a correspondence-generation utility.
