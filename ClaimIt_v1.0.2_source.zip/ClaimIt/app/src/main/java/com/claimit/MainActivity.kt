package com.claimit

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.*
import android.content.*
import android.net.Uri
import android.graphics.pdf.PdfDocument
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var category: Spinner
    private lateinit var fields: LinearLayout
    private lateinit var result: EditText
    private val inputs = mutableMapOf<String, EditText>()
    private val prefs by lazy { getSharedPreferences("claimit", MODE_PRIVATE) }

    private val categories = listOf(
        "Choose what you need",
        "Refund / money back",
        "Faulty or damaged product",
        "Late or missing delivery",
        "Complaint about a service",
        "Cancel a subscription or service",
        "Landlord / housing issue",
        "Workplace issue",
        "Insurance complaint",
        "Charge / card payment dispute",
        "Missed appointment / cancellation fee",
        "Data / privacy request",
        "Warranty / guarantee request",
        "Appeal / reconsideration",
        "Request information",
        "Other"
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 24)
        }

        root.addView(TextView(this).apply {
            text = "Claim It"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(17,24,39))
        })
        root.addView(TextView(this).apply {
            text = "Answer a few questions. Get a clear letter."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        })

        category = Spinner(this)
        category.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        root.addView(category)

        fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(fields)

        val create = Button(this).apply { text = "Create my letter" }
        root.addView(create)

        result = EditText(this).apply {
            hint = "Your letter will appear here. You can edit it."
            minLines = 15
            gravity = Gravity.TOP
            setTextIsSelectable(true)
        }
        root.addView(result)

        val actions = LinearLayout(this)
        val copy = Button(this).apply { text = "Copy" }
        val share = Button(this).apply { text = "Share" }
        val save = Button(this).apply { text = "Save" }
        val history = Button(this).apply { text = "History" }
        val pdf = Button(this).apply { text = "PDF" }
        actions.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(share, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(save, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)
        root.addView(history)
        root.addView(pdf)
        val newLetter = Button(this).apply { text = "New letter" }
        root.addView(newLetter)

        root.addView(TextView(this).apply {
            text = "FREE • No account • Your letters stay on your phone"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(75,85,99))
            setPadding(0, 12, 0, 6)
        })
        root.addView(TextView(this).apply {
            text = "Advertisement area"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 10)
        })
        val feedback = Button(this).apply { text = "Was this useful?" }
        root.addView(feedback)
        feedback.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Was Claim It useful?")
                .setMessage("Your feedback helps us improve the app. This prototype does not send feedback anywhere.")
                .setPositiveButton("Yes", null)
                .setNegativeButton("Not yet", null)
                .show()
        }

        val about = Button(this).apply { text = "About & Privacy" }
        root.addView(about)
        about.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("About Claim It")
                .setMessage(
                    "Claim It is a general correspondence tool. " +
                    "Your saved details and letters are stored locally on this device. " +
                    "This prototype does not upload your information to a server and does not provide professional legal advice."
                )
                .setPositiveButton("Close", null)
                .show()
        }

        root.addView(TextView(this).apply {
            text = "General correspondence tool. It does not provide professional legal advice."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 0)
        })

        scroll.addView(root)
        setContentView(scroll)

        category.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                rebuildQuestions(categories[pos])
            }
        }

        create.setOnClickListener { generate() }
        copy.setOnClickListener { copyResult() }
        share.setOnClickListener { shareResult() }
        save.setOnClickListener { saveLetter() }
        history.setOnClickListener { showHistory() }
        pdf.setOnClickListener { exportPdf() }
        newLetter.setOnClickListener {
            category.setSelection(0)
            result.text.clear()
        }
        if (!prefs.getBoolean("welcomeShown", false)) {
            AlertDialog.Builder(this)
                .setTitle("Welcome to Claim It")
                .setMessage("Answer a few simple questions and Claim It will turn them into a clear letter you can edit, copy, share or save as a PDF. Your information stays on this device.")
                .setPositiveButton("Let's go") { _, _ ->
                    prefs.edit().putBoolean("welcomeShown", true).apply()
                }
                .show()
        }
    }

    private fun addQuestion(key: String, label: String, hint: String, lines: Int = 2) {
        fields.addView(TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.rgb(55,65,81))
            setPadding(0, 12, 0, 3)
        })
        val e = EditText(this).apply {
            this.hint = hint
            minLines = lines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(prefs.getString(key, ""))
        }
        fields.addView(e)
        inputs[key] = e
    }

    private fun rebuildQuestions(type: String) {
        fields.removeAllViews()
        inputs.clear()
        if (type == categories.first()) return

        addQuestion("name", "Your name", "e.g. Alex Smith")
        addQuestion("contact", "Your contact details (optional)", "Email, phone or address", 2)

        when {
            type.startsWith("Refund") -> {
                addQuestion("business", "Who are you writing to?", "Company or seller")
                addQuestion("item", "What did you buy?", "Product or service")
                addQuestion("date", "When did you buy it?", "Date or approximate date")
                addQuestion("amount", "How much did it cost?", "Amount paid")
                addQuestion("problem", "What went wrong?", "Briefly explain the problem", 4)
                addQuestion("resolution", "What do you want?", "Refund, replacement, etc.")
            }
            type.startsWith("Faulty") -> {
                addQuestion("business", "Seller or company", "Name")
                addQuestion("item", "Product", "What is faulty?")
                addQuestion("date", "Purchase date", "Date or approximate date")
                addQuestion("problem", "What is wrong?", "Describe the fault", 4)
                addQuestion("resolution", "Preferred resolution", "Refund, repair, replacement")
            }
            type.startsWith("Late") -> {
                addQuestion("business", "Seller or delivery company", "Name")
                addQuestion("item", "What was ordered?", "Product")
                addQuestion("date", "Expected delivery", "Date")
                addQuestion("problem", "What happened?", "Missing, delayed, marked delivered, etc.", 4)
                addQuestion("resolution", "What do you want?", "Delivery, refund, investigation")
            }
            type.startsWith("Cancel") -> {
                addQuestion("business", "Company", "Name")
                addQuestion("service", "Service or subscription", "What are you cancelling?")
                addQuestion("problem", "Anything relevant?", "Account/order details or reason", 4)
            }
            type.startsWith("Landlord") -> {
                addQuestion("business", "Landlord / agent", "Name")
                addQuestion("property", "Property", "General property description")
                addQuestion("problem", "What is the issue?", "Describe the problem and when it started", 4)
                addQuestion("resolution", "What do you want?", "Repair, inspection, written response, etc.")
            }
            type.startsWith("Workplace") -> {
                addQuestion("business", "Employer / manager", "Name")
                addQuestion("problem", "What happened?", "Describe the workplace issue", 4)
                addQuestion("resolution", "What outcome do you want?", "Investigation, meeting, correction, etc.")
            }
            type.startsWith("Charge") -> {
                addQuestion("business", "Bank / card provider / merchant", "Name")
                addQuestion("date", "When was the payment?", "Date")
                addQuestion("amount", "Amount", "Amount charged")
                addQuestion("problem", "Why are you disputing it?", "Explain what happened", 4)
                addQuestion("resolution", "What do you want?", "Refund, investigation, charge reversal, etc.")
            }
            type.startsWith("Missed") -> {
                addQuestion("business", "Business", "Name")
                addQuestion("date", "Appointment date", "Date")
                addQuestion("problem", "What happened?", "Why was the appointment missed/cancelled?", 4)
                addQuestion("resolution", "What outcome do you want?", "Waive the fee, reschedule, refund, etc.")
            }
            type.startsWith("Data") -> {
                addQuestion("business", "Organisation", "Name")
                addQuestion("problem", "What do you want to request?", "Describe the information/privacy issue", 4)
                addQuestion("resolution", "What outcome do you want?", "Access, correction, deletion, explanation, etc.")
            }
            type.startsWith("Warranty") -> {
                addQuestion("business", "Seller / manufacturer", "Name")
                addQuestion("item", "Product", "What product is covered?")
                addQuestion("date", "Purchase date", "Date")
                addQuestion("problem", "What is wrong?", "Describe the fault", 4)
                addQuestion("resolution", "What do you want?", "Repair, replacement, refund, etc.")
            }
            else -> {
                addQuestion("business", "Who are you writing to?", "Company, organisation or person")
                addQuestion("problem", "What happened?", "Explain the situation clearly", 5)
                addQuestion("resolution", "What outcome do you want?", "What would resolve this for you?")
            }
        }
    }

    private fun v(key: String) = inputs[key]?.text?.toString()?.trim().orEmpty()

    private fun generate() {
        val type = category.selectedItem?.toString() ?: return
        if (type == categories.first()) return toast("Choose a type first.")
        val problem = v("problem")
        if (problem.isBlank()) return toast("Please describe what happened.")

        val name = v("name").ifBlank { "[Your name]" }
        val contact = v("contact")
        val business = v("business").ifBlank { "[Company / organisation]" }
        val resolution = v("resolution").ifBlank { "a clear written response explaining the position and next steps" }
        val opening = if (contact.isBlank()) "" else "$contact\n\n"

        val body = when {
            type.startsWith("Refund") -> """
Dear Sir/Madam,

I am writing regarding $business and my purchase of ${v("item").ifBlank { "[item/service]" }}.

Purchase date: ${v("date").ifBlank { "[date]" }}
Amount paid: ${v("amount").ifBlank { "[amount]" }}

The problem is:
$problem

I am requesting:
$resolution

Please review this matter and confirm in writing what action you will take and the expected timescale.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Faulty") -> """
Dear Sir/Madam,

I am writing regarding a faulty or damaged ${v("item").ifBlank { "product" }} purchased from $business.

Purchase date: ${v("date").ifBlank { "[date]" }}

The problem is:
$problem

My preferred resolution is:
$resolution

Please review the matter and confirm the next steps in writing.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Late") -> """
Dear Sir/Madam,

I am contacting you about an order for ${v("item").ifBlank { "an item" }}.

Expected delivery: ${v("date").ifBlank { "[date]" }}

The problem is:
$problem

I would like:
$resolution

Please confirm the current status and what action will be taken.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Cancel") -> """
Dear Sir/Madam,

I am writing to request cancellation of my ${v("service").ifBlank { "service/subscription" }} with $business.

Relevant details:
$problem

Please confirm in writing that the cancellation has been processed and advise whether any further payment will be taken.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Landlord") -> """
Dear Sir/Madam,

I am writing regarding an issue at ${v("property").ifBlank { "the property" }}.

The issue is:
$problem

I am requesting:
$resolution

Please acknowledge this correspondence and confirm the proposed next steps.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Workplace") -> """
Dear Sir/Madam,

I am writing to raise an issue regarding my workplace.

The situation is:
$problem

I would like the following outcome:
$resolution

Please acknowledge receipt and confirm how this matter will be addressed.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Charge") -> """
Dear Sir/Madam,

I am writing regarding a payment dispute.

Payment date: ${v("date").ifBlank { "[date]" }}
Amount: ${v("amount").ifBlank { "[amount]" }}

The reason for the dispute is:
$problem

I am requesting:
$resolution

Please investigate this matter and confirm the outcome in writing.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Missed") -> """
Dear Sir/Madam,

I am writing regarding an appointment and a related cancellation or missed-appointment charge.

Appointment date: ${v("date").ifBlank { "[date]" }}

The circumstances were:
$problem

I am requesting:
$resolution

Please review the circumstances and confirm your decision in writing.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Data") -> """
Dear Sir/Madam,

I am writing regarding a data or privacy request.

My request/concern is:
$problem

I would like:
$resolution

Please acknowledge this request and provide a written response.

Yours faithfully,

$name
""".trimIndent()

            type.startsWith("Warranty") -> """
Dear Sir/Madam,

I am writing regarding a warranty or guarantee issue concerning ${v("item").ifBlank { "a product" }}.

Purchase date: ${v("date").ifBlank { "[date]" }}

The problem is:
$problem

I am requesting:
$resolution

Please confirm the next steps in writing.

Yours faithfully,

$name
""".trimIndent()

            else -> """
Dear Sir/Madam,

I am writing regarding the following matter:

$problem

I would like the following outcome:
$resolution

Please acknowledge receipt and provide a clear written response.

Yours faithfully,

$name
""".trimIndent()
        }

        result.setText(opening + body)
        result.setSelection(0)
    }

    private fun saveLetter() {
        if (result.text.isBlank()) return toast("Create a letter first.")
        inputs.forEach { (key, edit) -> prefs.edit().putString(key, edit.text.toString()).apply() }
        val stamp = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())
        val old = prefs.getString("history", "") ?: ""
        val entry = "[$stamp] ${category.selectedItem}\n${result.text}\n---END---\n"
        prefs.edit().putString("history", (entry + old).take(12000)).apply()
        toast("Letter saved on this phone.")
    }

    private fun showHistory() {
        val raw = prefs.getString("history", "") ?: ""
        if (raw.isBlank()) return toast("No saved letters yet.")

        val entries = raw.split("\n---END---\n").filter { it.isNotBlank() }.toMutableList()
        if (entries.isEmpty()) return toast("No saved letters yet.")

        val labels = entries.mapIndexed { index, entry ->
            val lines = entry.lines()
            val stamp = lines.firstOrNull().orEmpty()
            val type = lines.drop(1).firstOrNull().orEmpty()
            "${index + 1}. $type ($stamp)"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Saved letters")
            .setItems(labels) { _, which ->
                showHistoryItem(entries, which)
            }
            .setNegativeButton("Close", null)
            .setNeutralButton("Clear all") { _, _ ->
                prefs.edit().remove("history").apply()
                toast("History cleared.")
            }
            .show()
    }

    private fun showHistoryItem(entries: MutableList<String>, index: Int) {
        val entry = entries[index]
        val letter = entry.substringAfter("\n", entry)
        AlertDialog.Builder(this)
            .setTitle("Saved letter")
            .setMessage(letter)
            .setPositiveButton("Load") { _, _ ->
                result.setText(letter)
                result.setSelection(0)
                toast("Letter loaded.")
            }
            .setNegativeButton("Delete") { _, _ ->
                entries.removeAt(index)
                prefs.edit().putString(
                    "history",
                    entries.joinToString("\n---END---\n") + if (entries.isNotEmpty()) "\n---END---\n" else ""
                ).apply()
                toast("Letter deleted.")
            }
            .setNeutralButton("Close", null)
            .show()
    }


    private fun exportPdf() {
        if (result.text.isBlank()) return toast("Create a letter first.")
        try {
            val doc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 48
            val paint = android.graphics.Paint().apply {
                textSize = 12f
                color = Color.BLACK
                isAntiAlias = true
            }
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            val maxWidth = pageWidth - margin * 2
            var y = margin + 14
            val lineHeight = 18

            result.text.toString().split("\n").forEach { paragraph ->
                if (paragraph.isBlank()) {
                    y += lineHeight
                    return@forEach
                }
                var line = ""
                paragraph.split(" ").forEach { word ->
                    val candidate = if (line.isEmpty()) word else "$line $word"
                    if (paint.measureText(candidate) > maxWidth) {
                        canvas.drawText(line, margin.toFloat(), y.toFloat(), paint)
                        y += lineHeight
                        line = word
                    } else line = candidate
                    if (y > pageHeight - margin) return@forEach
                }
                if (line.isNotEmpty() && y <= pageHeight - margin) {
                    canvas.drawText(line, margin.toFloat(), y.toFloat(), paint)
                    y += lineHeight
                }
            }
            doc.finishPage(page)

            val name = "ClaimIt_${System.currentTimeMillis()}.pdf"
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/Claim It")
            }
            val uri = contentResolver.insert(
                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            ) ?: return toast("Couldn't create the PDF.")
            contentResolver.openOutputStream(uri).use { doc.writeTo(it) }
            doc.close()
            toast("PDF saved to Downloads/Claim It.")
        } catch (e: Exception) {
            toast("Couldn't create the PDF.")
        }
    }

    private fun copyResult() {
        if (result.text.isBlank()) return toast("Create a letter first.")
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Claim It letter", result.text))
        toast("Letter copied.")
    }

    private fun shareResult() {
        if (result.text.isBlank()) return toast("Create a letter first.")
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, result.text.toString())
            }, "Share letter"
        ))
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
