package com.claimit;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setNavigationBarColor(Color.rgb(5, 2, 12));
        getWindow().setStatusBarColor(Color.rgb(5, 2, 12));
        setContentView(new SplashView(this));

        handler.postDelayed(() -> {
            MediaPlayer intro = MediaPlayer.create(this, com.claimit.R.raw.claim_it_intro);
            if (intro != null) {
                intro.setOnCompletionListener(MediaPlayer::release);
                intro.start();
            }
        }, 2000);

        handler.postDelayed(() -> setContentView(new WheelView(this)), 6000);
    }

    static class SplashView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap logo;
        RectF dst = new RectF();
        float pulse = 0;
        SplashView(Context c) {
            super(c);
            logo = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(
                    "ic_claimit", "drawable", c.getPackageName()));
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(Color.rgb(4, 1, 10));
            pulse += 0.035f;
            float glow = 18 + (float)Math.sin(pulse) * 4;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xff080313);
            p.setShadowLayer(glow, 0, 0, 0xffff238c);
            c.drawRoundRect(w*.08f, h*.24f, w*.92f, h*.76f, 36, 36, p);
            p.clearShadowLayer();
            if (logo != null) {
                float s = Math.min(w*.70f, h*.42f);
                dst.set((w-s)/2f, (h-s)/2f, (w+s)/2f, (h+s)/2f);
                p.setAlpha(255);
                c.drawBitmap(logo, null, dst, p);
            }
            postInvalidateDelayed(40);
        }
    }

    static class WheelView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap bg;
        float wheelAngle = 0f;
        float lastTouchAngle;
        float angularVelocity = 0f;
        long lastMoveTime;
        boolean dragging = false;
        boolean spinning = false;
        int selected = 0;
        int lastSoundIndex = 0;
        SoundPool soundPool;
        int tickId;
        boolean soundReady = false;
        RectF wheelRect = new RectF();
        final String[] cats = {
            "Make a formal complaint","Poor service complaint","Service not as described",
            "Request compensation","Request a written response","Warranty / guarantee request",
            "Landlord / contract issue","Workplace complaint","Refund or chargeback",
            "Billing or overcharge","Account / money issue","Poor customer service",
            "Faulty or damaged product","Delayed / missed refund"
        };
        final int[] colors = {
            0xffff2d55,0xff08a9c7,0xffff315f,0xff168ecf,0xffff315f,0xff08a9c7,
            0xffff8a00,0xffff2d55,0xff00aaa7,0xff11a9c7,0xff36c936,0xffff4c32,
            0xffd81b73,0xff7435e8
        };
        final String[] letters = {
            "Make a formal complaint","Poor service complaint","Service not as described",
            "Request compensation","Request a written response"
        };
        float cx, cy, radius;

        WheelView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            bg = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(
                "claimit_background","drawable",c.getPackageName()));
            text.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            soundPool = new SoundPool.Builder().setMaxStreams(3)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .build();
            tickId = soundPool.load(c, R.raw.tick, 1);
            soundPool.setOnLoadCompleteListener((sp, sampleId, status) -> soundReady = status == 0);
        }

        float pointAngle(float x,float y){ return (float)Math.atan2(y-cy,x-cx); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            if(bg!=null) c.drawBitmap(bg,null,new Rect(0,0,w,h),p);
            else c.drawColor(Color.rgb(5,2,12));

            // Compact upper playfield: big enough to read, but leaves room for the new letters section.
            cx=w/2f;
            cy=h*0.245f;
            radius=Math.min(w*0.405f,h*0.215f);

            drawHeader(c,w);
            drawWheel(c);
            drawLetters(c,w,h);
            drawNav(c,w,h);
        }

        void drawHeader(Canvas c,int w){
            text.setTextAlign(Paint.Align.CENTER);
            text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
            text.setTextSize(sp(28)); text.setColor(Color.WHITE);
            p.setShadowLayer(sp(9),0,0,0xffff1d91);
            c.drawText("CHOOSE YOUR LETTER",w/2f,sp(42),text);
            p.clearShadowLayer();
            text.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
            text.setTextSize(sp(13)); text.setColor(0xffffe7f4);
            c.drawText("Flick the wheel to spin it  •  Drag gently to position it exactly.",w/2f,sp(65),text);
        }

        void drawWheel(Canvas c){
            float sweep=360f/cats.length;
            // Neon outer rings and marquee dots.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(5)); p.setColor(0xffffb52d);
            p.setShadowLayer(sp(10),0,0,0xffff237e);
            c.drawCircle(cx,cy,radius+sp(7),p); p.clearShadowLayer();
            p.setStrokeWidth(sp(2)); p.setColor(0xff00eaff);
            c.drawCircle(cx,cy,radius+sp(14),p);
            for(int i=0;i<42;i++){
                double a=Math.toRadians(i*(360.0/42.0));
                float x=cx+(float)Math.cos(a)*(radius+sp(9));
                float y=cy+(float)Math.sin(a)*(radius+sp(9));
                p.setStyle(Paint.Style.FILL); p.setColor(i%2==0?0xffffd34f:0xffff4aa2);
                c.drawCircle(x,y,sp(2.4f),p);
            }

            for(int i=0;i<cats.length;i++){
                float start=(float)Math.toDegrees(wheelAngle) + i*sweep - sweep/2f;
                p.setStyle(Paint.Style.FILL); p.setColor(colors[i%colors.length]);
                c.drawArc(cx-radius,cy-radius,cx+radius,cy+radius,start,sweep+0.4f,true,p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(2)); p.setColor(0xff160b23);
                c.drawArc(cx-radius,cy-radius,cx+radius,cy+radius,start,sweep,true,p);
                drawRadialCategory(c,cats[i],start+sweep/2f);
            }

            // Centre hub.
            p.setStyle(Paint.Style.FILL); p.setColor(0xff080512); p.setShadowLayer(sp(12),0,0,0xffff267e);
            c.drawCircle(cx,cy,radius*0.20f,p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(4)); p.setColor(0xffffc52f);
            c.drawCircle(cx,cy,radius*0.20f,p);
            text.setTextAlign(Paint.Align.CENTER); text.setTextSize(sp(15)); text.setTypeface(Typeface.DEFAULT_BOLD); text.setColor(Color.WHITE);
            c.drawText("CLAIM IT",cx,cy+sp(5),text);

            // Right-hand pointer sits on the centre of a segment, never on a boundary.
            float ax=cx+radius+sp(9), ay=cy;
            Path tri=new Path();
            tri.moveTo(ax+sp(25),ay); tri.lineTo(ax,ay-sp(15)); tri.lineTo(ax,ay+sp(15)); tri.close();
            p.setStyle(Paint.Style.FILL); p.setColor(0xff00e6b8); p.setShadowLayer(sp(6),0,0,0xff00e6ff);
            c.drawPath(tri,p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(2)); p.setColor(Color.WHITE); c.drawPath(tri,p);
        }

        void drawRadialCategory(Canvas c, String s, float centerDeg){
            double a=Math.toRadians(centerDeg);
            float tx=cx+(float)Math.cos(a)*radius*0.60f;
            float ty=cy+(float)Math.sin(a)*radius*0.60f;
            float maxWidth=radius*0.70f;
            text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
            text.setTextSize(sp(15.5f)); text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER);
            text.setShadowLayer(sp(2),0,sp(1),0xff09030f);

            String[] parts=wrapForRadial(s,maxWidth);
            c.save();
            c.rotate(centerDeg,tx,ty);
            if(Math.cos(a)<0) c.rotate(180,tx,ty);
            if(parts.length==1){
                c.drawText(parts[0],tx,ty,text);
            } else {
                float gap=sp(17);
                c.drawText(parts[0],tx,ty-gap/2,text);
                c.drawText(parts[1],tx,ty+gap/2,text);
            }
            c.restore();
            text.clearShadowLayer();
        }

        String[] wrapForRadial(String s,float maxWidth){
            if(text.measureText(s)<=maxWidth) return new String[]{s};
            String[] w=s.split(" ");
            String best1="", best2="";
            for(int i=1;i<w.length;i++){
                String a=join(w,0,i), b=join(w,i,w.length);
                if(text.measureText(a)<=maxWidth && text.measureText(b)<=maxWidth){
                    best1=a; best2=b;
                    if(Math.abs(a.length()-b.length())<4) break;
                }
            }
            if(best1.isEmpty()){
                // Last resort: a concise label keeps the segment legible rather than shrinking to dust.
                if(s.equals("Warranty / guarantee request")) return new String[]{"Warranty / guarantee","request"};
                if(s.equals("Delayed / missed refund")) return new String[]{"Delayed / missed","refund"};
                if(s.equals("Service not as described")) return new String[]{"Service not as","described"};
                return new String[]{s.substring(0,Math.min(18,s.length())),""};
            }
            return new String[]{best1,best2};
        }

        String join(String[] a,int from,int to){
            StringBuilder b=new StringBuilder();
            for(int i=from;i<to;i++){ if(b.length()>0)b.append(' '); b.append(a[i]); }
            return b.toString();
        }

        void drawLetters(Canvas c,int w,int h){
            float top=h*0.505f;
            // New letters plaque — visually separated from the wheel and built for readable text.
            p.setStyle(Paint.Style.FILL); p.setColor(0xe5070712); p.setShadowLayer(sp(12),0,0,0xffff217d);
            c.drawRoundRect(sp(18),top,w-sp(18),top+sp(66),sp(18),sp(18),p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(3)); p.setColor(0xffffb52d);
            c.drawRoundRect(sp(18),top,w-sp(18),top+sp(66),sp(18),sp(18),p);
            text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD)); text.setTextSize(sp(23)); text.setColor(0xffffe26d);
            c.drawText(cats[selected],w/2f,top+sp(42),text);

            text.setTextSize(sp(13)); text.setTypeface(Typeface.DEFAULT); text.setColor(Color.WHITE);
            c.drawText("Choose the letter you want to make:",w/2f,top+sp(89),text);

            float y=top+sp(104);
            for(int i=0;i<letters.length;i++){
                p.setStyle(Paint.Style.FILL); p.setColor(i%2==0?0xffe91e57:0xff0799b0);
                p.setShadowLayer(sp(7),0,sp(2),0xffff1c7e);
                c.drawRoundRect(sp(24),y,w-sp(24),y+sp(50),sp(18),sp(18),p); p.clearShadowLayer();
                text.setTextSize(sp(16.5f)); text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD)); text.setColor(Color.WHITE);
                c.drawText(letters[i],w/2f-sp(5),y+sp(33),text);
                text.setTextSize(sp(27)); c.drawText("›",w-sp(48),y+sp(34),text);
                y+=sp(57);
            }
        }

        void drawNav(Canvas c,int w,int h){
            float y=h-sp(78);
            p.setStyle(Paint.Style.FILL); p.setColor(0xf305030d); c.drawRect(0,y,w,h,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(2)); p.setColor(0xffff278a); c.drawLine(0,y,w,y,p);
            String[] n={"⌂","◉","▤","☆","⚙"};
            String[] t={"HOME","WHEEL","LETTERS","FAVOURITES","SETTINGS"};
            for(int i=0;i<5;i++){
                float x=w*(i+.5f)/5f;
                text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.DEFAULT_BOLD);
                text.setTextSize(sp(23)); text.setColor(i==1?0xffff3d98:0xffffe7f2); c.drawText(n[i],x,y+sp(30),text);
                text.setTextSize(sp(9)); c.drawText(t[i],x,y+sp(51),text);
            }
        }

        float sp(float x){ return x*getResources().getDisplayMetrics().scaledDensity; }

        void playTick(){ if(soundReady) soundPool.play(tickId,0.9f,0.9f,1,0,1f); }

        int indexAtPointer(){
            float sweep=(float)(2*Math.PI/cats.length);
            int idx=Math.floorMod(Math.round(-wheelAngle/sweep),cats.length);
            return idx;
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(), y=e.getY();
            float dx=x-cx, dy=y-cy;
            if(dx*dx+dy*dy > (radius+sp(35))*(radius+sp(35))) return true;
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    dragging=true; spinning=false; angularVelocity=0;
                    lastTouchAngle=pointAngle(x,y); lastMoveTime=SystemClock.uptimeMillis();
                    lastSoundIndex=indexAtPointer();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(!dragging) return true;
                    float a=pointAngle(x,y);
                    float d=a-lastTouchAngle;
                    if(d>Math.PI)d-=2*Math.PI; if(d<-Math.PI)d+=2*Math.PI;
                    wheelAngle+=d;
                    long now=SystemClock.uptimeMillis();
                    float dt=Math.max(8,now-lastMoveTime)/1000f;
                    angularVelocity=d/dt;
                    lastTouchAngle=a; lastMoveTime=now;
                    int idx=indexAtPointer();
                    if(idx!=lastSoundIndex){ playTick(); lastSoundIndex=idx; }
                    selected=idx;
                    invalidate(); return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if(!dragging) return true;
                    dragging=false;
                    if(Math.abs(angularVelocity)>1.25f){ spinning=true; post(spinRunner); }
                    else snapToSegment();
                    return true;
            }
            return true;
        }

        void snapToSegment(){
            final float sweep=(float)(2*Math.PI/cats.length);
            final float start=wheelAngle;
            final float end=(float)(Math.round(start/sweep)*sweep);
            final long st=SystemClock.uptimeMillis();
            post(new Runnable(){ public void run(){
                float t=Math.min(1f,(SystemClock.uptimeMillis()-st)/180f);
                float e=1-(1-t)*(1-t);
                wheelAngle=start+(end-start)*e;
                selected=indexAtPointer();
                invalidate();
                if(t<1) post(this); else { wheelAngle=end; selected=indexAtPointer(); invalidate(); }
            }});
        }

        final Runnable spinRunner=new Runnable(){ public void run(){
            if(dragging) return;
            wheelAngle+=angularVelocity/60f;
            angularVelocity*=0.982f;
            int idx=indexAtPointer();
            if(idx!=lastSoundIndex){ playTick(); lastSoundIndex=idx; }
            selected=idx; invalidate();
            if(Math.abs(angularVelocity)>0.035f) postDelayed(this,16);
            else { angularVelocity=0; spinning=false; snapToSegment(); }
        }};
    }
}
