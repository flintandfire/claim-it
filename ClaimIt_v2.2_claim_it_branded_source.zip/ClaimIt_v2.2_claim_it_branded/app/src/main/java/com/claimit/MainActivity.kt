package com.claimit

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {
    private val pink = Color.rgb(250, 185, 221)
    private val purple = Color.rgb(170, 91, 196)
    private val deepPurple = Color.rgb(58, 28, 78)
    private val lilac = Color.rgb(224, 200, 242)
    private val cream = Color.rgb(255, 250, 253)
    private val dark = Color.rgb(15, 8, 27)
    private val white = Color.WHITE
    private var screenNo = 0
    private val prefs by lazy { getSharedPreferences("claimit", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val inputs = mutableMapOf<String, EditText>()
    private var selectedType = ""
    private var result: EditText? = null
    private val categories = listOf(
        "Refund / money back", "Faulty or damaged product", "Late or missing delivery",
        "Complaint about a service", "Cancel a subscription or service", "Landlord / housing issue",
        "Workplace issue", "Insurance complaint", "Charge / card payment dispute",
        "Missed appointment / cancellation fee", "Data / privacy request", "Warranty / guarantee request",
        "Appeal / reconsideration", "Request information", "Other"
    )

    override fun onCreate(state: Bundle?) { super.onCreate(state); splashThenHome() }

    private fun splashThenHome() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(dark)
            setPadding(18, 30, 18, 30)
        }
        val logo = ImageView(this).apply {
            setImageResource(com.claimit.R.drawable.claim_it_main_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Claim It — powered by Flint & Fire"
        }
        box.addView(logo, LinearLayout.LayoutParams(-1, 0, 1f))
        val launch = TextView(this).apply {
            text = "Letters made clearer. People made more confident."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(242, 214, 238))
            setPadding(8, 12, 8, 4)
        }
        box.addView(launch, LinearLayout.LayoutParams(-1, -2))
        setContentView(box)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        window.decorView.postDelayed({ home() }, 1500)
    }

    private fun base(): ScrollView {
        screenNo++
        val bg = when (screenNo % 3) { 1 -> white; 2 -> cream; else -> Color.rgb(249, 237, 249) }
        window.statusBarColor = deepPurple
        window.navigationBarColor = deepPurple
        val scroll=ScrollView(this)
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,28);setBackgroundColor(bg)}
        scroll.addView(root)
        return scroll
    }
    private fun title(t:String, sub:String="") { root.addView(TextView(this).apply{text=t;textSize=30f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple);setPadding(4,4,4,0)}); if(sub.isNotBlank()) root.addView(TextView(this).apply{text=sub;textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,2,6,18)}) }
    private fun button(text:String, onClick:()->Unit, filled:Boolean=false): Button { val b=Button(this).apply{this.text=text;textSize=15f;isAllCaps=false;setOnClickListener{onClick()};setPadding(12,10,12,10)}; b.background=GradientDrawable().apply{cornerRadius=22f;setColor(if(filled) purple else lilac)};b.setTextColor(if(filled)Color.WHITE else deepPurple);root.addView(b,LinearLayout.LayoutParams(-1,58).apply{setMargins(0,7,0,7)});return b }
    private fun home(){
        val s=base();title("Claim It","Letters made clearer. People made more confident.")
        card("MY LETTERS","Open saved projects and see when they were last edited."){ myLetters() }
        card("NEW LETTER","Choose what you need. The full letter directory lives here."){ directory() }
        card("ASSISTANCE & GUIDANCE","Plain-English help on what to put in each box."){ support() }
        card("CUSTOMER SUPPORT","Feedback, contact and app information."){ support() }
        card("ABOUT & PRIVACY","What Claim It does, what it stores and what it does not send anywhere."){ aboutPrivacy() }
        card("WORTH-IT","Reviews and useful product experiences — coming next."){ worthIt() }
        root.addView(TextView(this).apply{text="Advertisement";textSize=10f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,20,0,4)})
        root.addView(TextView(this).apply{text="Free to use • no account required • letters stay on your phone";textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,10,0,0)})
        setContentView(s)
    }
    private fun card(head:String, sub:String, click:()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,15,18,15);background=GradientDrawable().apply{cornerRadius=26f;setColor(pink)};setOnClickListener{click()}};c.addView(TextView(this).apply{text=head;textSize=18f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple)});c.addView(TextView(this).apply{text=sub;textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,3,0,0)});root.addView(c,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})}
    private fun backButton(){button("‹  Back",{home()})}

    private fun directory(){
        val s=base();title("Choose your letter","Spin the dial or tap a category.")
        val wheel=WheelView(this,categories){type->letterForm(type)};root.addView(wheel,LinearLayout.LayoutParams(-1,360));
        categories.forEach{t->button(t,{letterForm(t)},false)}
        backButton();setContentView(s)
    }

    private fun letterForm(type:String){
        selectedType=type; val s=base();title(type,"Tell us the facts. The letter does the talking.")
        val info=TextView(this).apply{text="Date fields open a calendar. Your phone's autofill can fill supported personal details.";textSize=12f;setTextColor(Color.DKGRAY);setPadding(6,0,6,12)};root.addView(info)
        inputs.clear(); addField("name","Your name","Name",1,true);addField("contact","Contact details","Email, phone or address",2,true)
        when{type.startsWith("Refund")-> {addField("business","Company / seller","Who are you writing to?");addField("item","Purchase","What did you buy?");dateField("date","Purchase date");addField("amount","Amount paid","£");addField("problem","What went wrong?","Explain clearly",4);addField("resolution","What would you like?","Refund, replacement or other outcome",2)}
            type.startsWith("Faulty")-> {addField("business","Seller / company","Name");addField("item","Product","What is faulty?");dateField("date","Purchase date");addField("problem","What is wrong?","Describe the fault",4);addField("resolution","Preferred resolution","Repair, replacement or refund",2)}
            type.startsWith("Late")-> {addField("business","Seller / delivery company","Name");addField("item","Order","What was ordered?");dateField("date","Expected delivery");addField("problem","What happened?","Delayed, missing, marked delivered, etc.",4);addField("resolution","What do you want?","Delivery, refund or investigation",2)}
            type.startsWith("Cancel")-> {addField("business","Company","Name");addField("service","Service / subscription","What are you cancelling?");addField("problem","Relevant details","Account or order details",4)}
            type.startsWith("Landlord")-> {addField("business","Landlord / agent","Name");addField("property","Property","General description");addField("problem","What is the issue?","Describe it and when it started",4);addField("resolution","What do you want?","Repair, inspection or response",2)}
            type.startsWith("Workplace")-> {addField("business","Employer / manager","Name");addField("problem","What happened?","Describe the workplace issue",4);addField("resolution","Desired outcome","Investigation, meeting or correction",2)}
            type.startsWith("Charge")-> {addField("business","Bank / merchant","Name");dateField("date","Payment date");addField("amount","Amount","£");addField("problem","Why are you disputing it?","Explain what happened",4);addField("resolution","What do you want?","Refund, reversal or investigation",2)}
            else->{addField("business","Who are you writing to?","Company, organisation or person");addField("problem","What happened?","Explain the situation clearly",5);addField("resolution","What outcome do you want?","What would resolve this?",2)}}
        button("Create my letter",{generate()},true); result=EditText(this).apply{hint="Your letter will appear here. You can edit it.";minLines=14;gravity=Gravity.TOP;textSize=15f;setTextColor(Color.DKGRAY);setPadding(18,18,18,18);background=GradientDrawable().apply{cornerRadius=18f;setColor(Color.WHITE);setStroke(2,lilac)} };root.addView(result,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,8)});button("Copy",{copyResult()});button("Share",{shareResult()});button("Save / update",{saveLetter()});button("Export PDF",{exportPdf()});button("‹  Back to directory",{directory()});setContentView(s)
    }
    private fun addField(key:String,label:String,hint:String,lines:Int=2,autofill:Boolean=false){root.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(deepPurple);setPadding(6,9,6,2)});val e=EditText(this).apply{this.hint=hint;minLines=lines;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;setText(prefs.getString(key,""));if(autofill){when(key){"name"->autofillHints=arrayOf("name");"contact"->autofillHints=arrayOf("emailAddress","phone","postalAddress")}}};root.addView(e);inputs[key]=e}
    private fun dateField(key:String,label:String){root.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(deepPurple);setPadding(6,9,6,2)});val e=EditText(this).apply{hint="Tap to choose date";isFocusable=false;setText(prefs.getString(key,""));setOnClickListener{val c=Calendar.getInstance();DatePickerDialog(this@MainActivity,{_,y,m,d->setText(String.format(Locale.getDefault(),"%02d/%02d/%04d",d,m+1,y))},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}};root.addView(e);inputs[key]=e}
    private fun v(k:String)=inputs[k]?.text?.toString()?.trim().orEmpty()
    private fun generate(){val r=result?:return;val name=v("name").ifBlank{"[Your name]"};val business=v("business").ifBlank{"[Company / organisation]"};val problem=v("problem");if(problem.isBlank()){toast("Please describe what happened.");return};val resolution=v("resolution").ifBlank{"a clear written response and the next steps"};val text="Dear Sir/Madam,\n\nI am writing regarding $selectedType.\n\n${if(v("item").isNotBlank())"Item: ${v("item")}\n" else ""}${if(v("date").isNotBlank())"Date: ${v("date")}\n" else ""}${if(v("amount").isNotBlank())"Amount: ${v("amount")}\n" else ""}\nThe situation is:\n$problem\n\nI would like: \n$resolution\n\nPlease review this matter and confirm in writing what action you will take and the expected timescale.\n\nYours faithfully,\n\n$name";r.setText(text);r.setSelection(0)}
    private fun saveLetter(){val r=result?:return;if(r.text.isBlank()){toast("Create a letter first.");return};val now=SimpleDateFormat("dd MMM yyyy HH:mm",Locale.getDefault()).format(Date());inputs.forEach{(k,e)->prefs.edit().putString(k,e.text.toString()).apply()};val old=prefs.getString("history","")?:"";val entry="[$now] $selectedType\n${r.text}\n---END---\n";prefs.edit().putString("history",(entry+old).take(30000)).apply();toast("Saved — $now")}
    private fun myLetters(){val raw=prefs.getString("history","")?:"";val s=base();title("My Letters","Your projects, with the last edit time saved.");if(raw.isBlank())root.addView(TextView(this).apply{text="Nothing saved yet. Create a letter and tap Save / update.";textSize=16f;setPadding(6,20,6,20)});else raw.split("\n---END---\n").filter{it.isNotBlank()}.forEachIndexed{idx,e->val lines=e.lines();val stamp=lines.firstOrNull().orEmpty();val type=lines.drop(1).firstOrNull().orEmpty();card(type,stamp){AlertDialog.Builder(this).setTitle(type).setMessage(e.substringAfter("\n")).setPositiveButton("Load"){_,_->letterForm(type)}.setNegativeButton("Delete"){_,_->toast("Delete from My Letters coming in the next build.")}.show()}};button("+ New letter",{directory()},true);backButton();setContentView(s)}
    private fun deleteHistoryEntry(index:Int){
        val raw=prefs.getString("history","")?:""
        val entries=raw.split("\n---END---\n").filter{it.isNotBlank()}.toMutableList()
        if(index in entries.indices){ entries.removeAt(index); prefs.edit().putString("history",entries.joinToString("\n---END---\n")).apply(); toast("Letter deleted") }
        myLetters()
    }
    private fun aboutPrivacy(){
        val s=base(); title("About & privacy","Claim It is designed to keep ordinary correspondence simple and local-first.")
        listOf(
            "Your saved letter history is stored locally on this device.",
            "Claim It does not require an account to create letters.",
            "The app does not send your letter contents to a Claim It server or AI API.",
            "Sharing and PDF export happen only when you choose those actions.",
            "Templates are general correspondence tools, not professional legal advice."
        ).forEach{root.addView(TextView(this).apply{text="• $it";textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,10,6,10)})}
        button("‹ Back",{home()}); setContentView(s)
    }
    private fun support(){val s=base();title("Assistance & guidance","Clear, simple instructions — no guesswork.");listOf("Your name — usually the name on your account or correspondence.","Company — check the invoice, receipt, website or previous emails.","Date — check your receipt, order history, bank statement or appointment confirmation.","Amount — check your receipt or bank/card statement.","Location — use the address shown on the relevant bill, booking or contract.","Problem — stick to what happened, when it happened and what evidence you have.","Outcome — say what you want the company to do to put things right.").forEach{root.addView(TextView(this).apply{text="• $it";textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,10,6,10)})};root.addView(TextView(this).apply{text="Templates are designed as general correspondence and should be checked for your circumstances. Claim It does not provide professional legal advice.";textSize=12f;setTextColor(Color.GRAY);setPadding(6,18,6,10)});button("‹ Back",{home()});setContentView(s)}
    private fun worthIt(){val s=base();title("WORTH-IT","A friendly reviews section built around useful experiences.");root.addView(TextView(this).apply{text="Coming next: product and service reviews, quick pros/cons, and a simple 'Was it worth it?' verdict.";textSize=16f;setTextColor(Color.DKGRAY);setPadding(6,12,6,24)});button("‹ Back",{home()});setContentView(s)}
    private fun copyResult(){val r=result?:return;getSystemService(CLIPBOARD_SERVICE).let{(it as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Claim It",r.text))};toast("Copied")}
    private fun shareResult(){val r=result?:return;if(r.text.isBlank())return toast("Create a letter first.");startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,r.text)},"Share letter"))}
    private fun exportPdf(){val r=result?:return;if(r.text.isBlank())return toast("Create a letter first.");if(android.os.Build.VERSION.SDK_INT < 29)return toast("PDF export needs Android 10 or newer.");val doc=android.graphics.pdf.PdfDocument();val info=android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create();val p=doc.startPage(info);val paint=Paint().apply{textSize=12f;color=Color.DKGRAY};var y=55f;r.text.toString().lines().forEach{line->p.canvas.drawText(line.take(90),45f,y,paint);y+=18;if(y>800f)return@forEach};doc.finishPage(p);val name="ClaimIt_${System.currentTimeMillis()}.pdf";val cv=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,"Download/Claim It")};val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv)?:return toast("Couldn't create PDF");val output = contentResolver.openOutputStream(uri)
            ?: return toast("Couldn't open PDF output")
        output.use { doc.writeTo(it) }
        doc.close()
        toast("PDF saved to Downloads/Claim It")}
    private fun toast(t:String){Toast.makeText(this,t,Toast.LENGTH_SHORT).show()}

    class WheelView(
        c: Context,
        private val items: List<String>,
        private val pick: (String) -> Unit
    ) : View(c) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var angle = 0f
        private var down = 0f
        private var last = 0f

        init {
            isClickable = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = min(width, height) * .34f

            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(126, 77, 156)
            canvas.drawCircle(cx, cy, r + 35, paint)
            paint.color = Color.rgb(250, 224, 244)
            canvas.drawCircle(cx, cy, r, paint)
            paint.color = Color.rgb(76, 45, 97)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 17f
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("CHOOSE", cx, cy - 5, paint)
            canvas.drawText("YOUR LETTER", cx, cy + 18, paint)

            paint.textSize = 12f
            paint.typeface = Typeface.DEFAULT
            for (i in items.indices) {
                val a = Math.toRadians((i * 360f / items.size + angle - 90).toDouble())
                val x = cx + cos(a) * r
                val y = cy + sin(a) * r
                paint.color = Color.WHITE
                canvas.drawCircle(x.toFloat(), y.toFloat(), 31f, paint)
                paint.color = Color.rgb(76, 45, 97)
                canvas.drawText("${i + 1}", x.toFloat(), y.toFloat() + 4, paint)
            }

            paint.color = Color.rgb(126, 77, 156)
            paint.strokeWidth = 8f
            canvas.drawLine(cx, 18f, cx, 55f, paint)
        }

        override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
            val cx = width / 2f
            val cy = height / 2f

            fun a(x: Float, y: Float): Float =
                Math.toDegrees(
                    atan2((y - cy).toDouble(), (x - cx).toDouble())
                ).toFloat()

            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    down = a(e.x, e.y)
                    last = down
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val n = a(e.x, e.y)
                    var d = n - last
                    if (d > 180) d -= 360
                    if (d < -180) d += 360
                    angle += d
                    last = n
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val n = a(e.x, e.y)
                    val total = n - down
                    if (total > -12 && total < 12) {
                        val idx = (((-angle + 90) / 360f * items.size).roundToInt() % items.size + items.size) % items.size
                        pick(items[idx])
                    }
                    return true
                }
            }
            return true
        }
    }

}
