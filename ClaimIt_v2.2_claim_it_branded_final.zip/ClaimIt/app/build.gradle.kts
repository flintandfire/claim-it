plugins {
    id("com.android.application")
}

android {
    namespace = "com.claimit"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.claimit"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "2.3.0"
    }
}

dependencies {
}
