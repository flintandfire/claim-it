package com.claimit

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.speech.tts.TextToSpeech
import android.media.AudioAttributes
import android.media.SoundPool
import android.animation.ValueAnimator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {
    private var tts: TextToSpeech? = null
    private var soundPool: SoundPool? = null
    private var wheelTickSound = 0
    private var wheelStopSound = 0
    private val pink = Color.rgb(250, 185, 221)
    private val purple = Color.rgb(170, 91, 196)
    private val deepPurple = Color.rgb(58, 28, 78)
    private val lilac = Color.rgb(224, 200, 242)
    private val cream = Color.rgb(255, 250, 253)
    private val dark = Color.rgb(15, 8, 27)
    private val white = Color.WHITE
    private var screenNo = 0
    private val prefs by lazy { getSharedPreferences("claimit", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val inputs = mutableMapOf<String, EditText>()
    private var selectedType = ""
    private var result: EditText? = null
    private val pageStack = ArrayDeque<() -> Unit>()
    private var currentPage: (() -> Unit)? = null
    private var selectedLettersView: LinearLayout? = null
    private val letterChoices = mapOf(
        "Refund / money back" to listOf("Ask for a full refund","Ask for a partial refund","Refund for a returned item","Refund for a cancelled service","Refund for a duplicate payment"),
        "Faulty or damaged product" to listOf("Faulty product complaint","Request a repair","Request a replacement","Request a refund","Report damage on delivery"),
        "Late or missing delivery" to listOf("Late delivery complaint","Item marked delivered but missing","Missing parcel investigation","Request a delivery refund","Delivery deadline complaint"),
        "Complaint about a service" to listOf("Make a formal complaint","Poor service complaint","Service not as described","Request compensation","Request a written response"),
        "Cancel a subscription or service" to listOf("Cancel a subscription","Cancel during a cooling-off period","Stop a recurring payment","Confirm cancellation in writing","Request a final bill"),
        "Landlord / housing issue" to listOf("Request a repair","Report an urgent repair","Report damp or mould","Complaint about an agent","Request an inspection"),
        "Workplace issue" to listOf("Raise a workplace concern","Make a formal grievance","Request a meeting","Challenge a workplace decision","Request written clarification"),
        "Insurance complaint" to listOf("Challenge an insurance decision","Dispute a claim outcome","Complaint about delay","Request reasons for refusal","Request a reassessment"),
        "Charge / card payment dispute" to listOf("Dispute a card payment","Challenge an unauthorised payment","Request a chargeback","Dispute a duplicate charge","Challenge an incorrect amount"),
        "Missed appointment / cancellation fee" to listOf("Challenge a cancellation fee","Explain a missed appointment","Request a fee waiver","Request a refund of a fee","Ask for a new appointment"),
        "Data / privacy request" to listOf("Request my personal data","Ask for data correction","Request deletion","Object to data use","Ask how my data is used"),
        "Warranty / guarantee request" to listOf("Make a warranty claim","Request a repair under warranty","Request a replacement under warranty","Challenge a warranty refusal","Ask for guarantee support"),
        "Appeal / reconsideration" to listOf("Request reconsideration","Appeal a decision","Challenge a penalty","Ask for a review","Provide additional evidence"),
        "Request information" to listOf("Make an information request","Ask for records","Request a copy of an agreement","Ask for reasons","Request confirmation in writing"),
        "Other" to listOf("General complaint","Request action","Ask for an explanation","Request a written response","Other correspondence")
    )
    private val categories = listOf(
        "Refund / money back", "Faulty or damaged product", "Late or missing delivery",
        "Complaint about a service", "Cancel a subscription or service", "Landlord / housing issue",
        "Workplace issue", "Insurance complaint", "Charge / card payment dispute",
        "Missed appointment / cancellation fee", "Data / privacy request", "Warranty / guarantee request",
        "Appeal / reconsideration", "Request information", "Other"
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        initAudio()
        splashThenHome()
    }

    private fun initAudio() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        wheelTickSound = soundPool?.load(this, com.claimit.R.raw.wheel_clack, 1) ?: 0
        wheelStopSound = soundPool?.load(this, com.claimit.R.raw.wheel_stop, 1) ?: 0
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.UK
                tts?.setPitch(0.72f)
                tts?.setSpeechRate(0.82f)
                window.decorView.postDelayed({
                    tts?.speak("Claim It", TextToSpeech.QUEUE_FLUSH, null, "claim-it-start")
                }, 450)
            }
        }
    }

    internal fun playWheelTick() {
        val id = wheelTickSound
        if (id != 0) soundPool?.play(id, 0.72f, 0.72f, 1, 0, 0.95f + Random().nextFloat() * 0.12f)
    }

    internal fun playWheelStop() {
        val id = wheelStopSound
        if (id != 0) soundPool?.play(id, 0.9f, 0.9f, 2, 0, 1.0f)
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        soundPool?.release()
        soundPool = null
        super.onDestroy()
    }

    private fun splashThenHome() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(dark)
            setPadding(18, 30, 18, 30)
        }
        val logo = ImageView(this).apply {
            setImageResource(com.claimit.R.drawable.claim_it_main_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Claim It — powered by Flint & Fire"
        }
        box.addView(logo, LinearLayout.LayoutParams(-1, 0, 1f))
        val launch = TextView(this).apply {
            text = "Letters made clearer. People made more confident."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(242, 214, 238))
            setPadding(8, 12, 8, 4)
        }
        box.addView(launch, LinearLayout.LayoutParams(-1, -2))
        setContentView(box)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        window.decorView.postDelayed({ home() }, 1500)
    }

    private fun base(): ScrollView {
        screenNo++
        val bg = when (screenNo % 3) { 1 -> white; 2 -> cream; else -> Color.rgb(249, 237, 249) }
        window.statusBarColor = deepPurple
        window.navigationBarColor = deepPurple
        val scroll=ScrollView(this)
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,28);setBackgroundColor(bg)}
        scroll.addView(root)
        return scroll
    }
    private fun title(t:String, sub:String="") { root.addView(TextView(this).apply{text=t;textSize=30f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple);setPadding(4,4,4,0)}); if(sub.isNotBlank()) root.addView(TextView(this).apply{text=sub;textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,2,6,18)}) }
    private fun button(text:String, onClick:()->Unit, filled:Boolean=false): Button {
        val b=Button(this).apply{
            this.text=text
            textSize=15f
            isAllCaps=false
            gravity=Gravity.CENTER
            minHeight=60
            minimumHeight=60
            maxLines=3
            includeFontPadding=true
            setLineSpacing(1f,1.05f)
            setOnClickListener{onClick()}
            setPadding(16,12,16,12)
        }
        b.background=GradientDrawable().apply{cornerRadius=24f;setColor(if(filled) purple else lilac)}
        b.setTextColor(if(filled)Color.WHITE else deepPurple)
        root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})
        return b
    }
    private fun navButton(text:String, onClick:()->Unit, filled:Boolean=false): Button {
        return button(text,{ currentPage?.let{pageStack.addLast(it)}; onClick() },filled)
    }
    private fun goBack(){
        if(pageStack.isNotEmpty()) pageStack.removeLast().invoke() else home()
    }
    override fun onBackPressed(){
        if(pageStack.isNotEmpty()) goBack() else super.onBackPressed()
    }
    private fun home(){
        pageStack.clear()
        currentPage = { home() }
        val s=base();title("Claim It","Letters made clearer. People made more confident.")
        card("MY LETTERS","Open saved projects and see when they were last edited."){ myLetters() }
        card("NEW LETTER","Choose what you need. The full letter directory lives here."){ directory() }
        card("ASSISTANCE & GUIDANCE","Plain-English help on what to put in each box."){ support() }
        card("CUSTOMER SUPPORT","Feedback, contact and app information."){ support() }
        card("ABOUT & PRIVACY","What Claim It does, what it stores and what it does not send anywhere."){ aboutPrivacy() }
        card("WORTH-IT","Reviews and useful product experiences — coming next."){ worthIt() }
        root.addView(TextView(this).apply{text="Advertisement";textSize=10f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,20,0,4)})
        root.addView(TextView(this).apply{text="Free to use • no account required • letters stay on your phone";textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,10,0,0)})
        setContentView(s)
    }
    private fun card(head:String, sub:String, click:()->Unit){
        val c=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(18,15,18,15)
            background=GradientDrawable().apply{cornerRadius=26f;setColor(pink)}
            setOnClickListener{currentPage?.let{pageStack.addLast(it)};click()}
        }
        c.addView(TextView(this).apply{text=head;textSize=18f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple)})
        c.addView(TextView(this).apply{text=sub;textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,3,0,0)})
        root.addView(c,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})
    }
    private fun backButton(){button("‹  Back",{goBack()})}

    private fun directory(){
        currentPage = { directory() }
        window.statusBarColor = Color.rgb(12, 5, 22)
        window.navigationBarColor = Color.rgb(12, 5, 22)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(12, 5, 22))

        val frame = FrameLayout(this)
        val backdrop = ImageView(this).apply {
            setImageResource(com.claimit.R.drawable.pinball_backdrop)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = null
        }
        frame.addView(backdrop, FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 30)
            setBackgroundColor(Color.TRANSPARENT)
        }

        val heading = TextView(this).apply {
            text = "CHOOSE YOUR LETTER"
            textSize = 30f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 0f, Color.rgb(255, 40, 120))
            setPadding(4, 4, 4, 2)
        }
        content.addView(heading, LinearLayout.LayoutParams(-1, -2))

        val instruction = TextView(this).apply {
            text = "Flick the wheel to spin it. Drag gently to position it exactly."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 239, 250))
            setPadding(8, 0, 8, 10)
        }
        content.addView(instruction, LinearLayout.LayoutParams(-1, -2))

        // The generated artwork supplies the neon cabinet and pinball scenery;
        // this opaque panel masks its decorative/static wheel so our real wheel
        // remains the only interactive wheel the user sees.
        val wheelPanel = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = 38f
                setColor(Color.argb(245, 12, 5, 22))
                setStroke(5, Color.rgb(255, 190, 62))
            }
            elevation = 8f
        }
        val wheel = WheelView(this, categories) { type -> showLetterChoices(type) }
        wheelPanel.addView(wheel, FrameLayout.LayoutParams(-1, 430))
        content.addView(wheelPanel, LinearLayout.LayoutParams(-1, 430).apply {
            setMargins(0, 4, 0, 12)
        })

        content.addView(TextView(this).apply {
            text = "Stop on a subject to reveal the letters in that category."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(8, 6, 8, 10)
        }, LinearLayout.LayoutParams(-1, -2))

        val panelTitle = TextView(this).apply {
            text = "CHOOSE YOUR LETTER"
            textSize = 22f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 230, 130))
            setShadowLayer(7f, 0f, 0f, Color.rgb(255, 70, 120))
            setPadding(8, 8, 8, 8)
            background = GradientDrawable().apply {
                cornerRadius = 22f
                setColor(Color.argb(235, 16, 7, 30))
                setStroke(3, Color.rgb(255, 70, 120))
            }
        }
        content.addView(panelTitle, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 4, 0, 6)
        })

        selectedLettersView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
            background = GradientDrawable().apply {
                cornerRadius = 30f
                setColor(Color.argb(245, 10, 5, 20))
                setStroke(4, Color.rgb(255, 190, 62))
            }
            addView(TextView(this@MainActivity).apply {
                text = "Spin the wheel to reveal the letter choices."
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(255, 239, 250))
                setPadding(10, 24, 10, 24)
            })
        }
        content.addView(selectedLettersView, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, 12)
        })

        val browse = Button(this).apply {
            text = "Browse all subjects"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.rgb(67, 25, 91))
                setStroke(2, Color.rgb(255, 190, 62))
            }
            setOnClickListener { showAllSubjects() }
        }
        content.addView(browse, LinearLayout.LayoutParams(-1, 60).apply {
            setMargins(0, 5, 0, 5)
        })

        val back = Button(this).apply {
            text = "‹  Back"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.rgb(67, 25, 91))
                setStroke(2, Color.rgb(255, 190, 62))
            }
            setOnClickListener { goBack() }
        }
        content.addView(back, LinearLayout.LayoutParams(-1, 60).apply {
            setMargins(0, 5, 0, 0)
        })

        frame.addView(content, FrameLayout.LayoutParams(-1, -2))
        scroll.addView(frame, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)
    }

    private fun showLetterChoices(type:String){
        selectedType=type
        val holder=selectedLettersView ?: return
        holder.removeAllViews()
        holder.addView(TextView(this).apply{
            text=type
            textSize=22f
            typeface=Typeface.create("sans-serif-condensed",Typeface.BOLD)
            setTextColor(Color.rgb(255,230,130))
            gravity=Gravity.CENTER
            setShadowLayer(6f,0f,0f,Color.rgb(255,50,120))
            setPadding(8,12,8,6)
        })
        holder.addView(TextView(this).apply{
            text="Choose the letter you want to make:"
            textSize=14f
            setTextColor(Color.WHITE)
            gravity=Gravity.CENTER
            setPadding(8,0,8,8)
        })
        letterChoices[type].orEmpty().forEachIndexed{index,letter->
            val b=buttonView(letter,index%2==0)
            b.setOnClickListener{pageStack.addLast(currentPage ?: {directory()});letterForm(type)}
            holder.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)})
        }
        holder.visibility=View.VISIBLE
    }

    private fun buttonView(text:String,accent:Boolean):Button{
        return Button(this).apply{
            this.text=text
            textSize=15f
            isAllCaps=false
            gravity=Gravity.CENTER
            minHeight=58
            maxLines=3
            setPadding(16,12,16,12)
            setTextColor(Color.WHITE)
            background=GradientDrawable().apply{
                cornerRadius=22f
                setColor(if(accent)Color.rgb(224,31,83) else Color.rgb(8,137,157))
                setStroke(2,Color.rgb(255,225,110))
            }
        }
    }

    private fun showAllSubjects(){
        val s=base()
        title("All subjects","Choose a subject directly, or use the spinning wheel to browse visually.")
        categories.forEach{t->navButton(t,{letterForm(t)},false)}
        backButton()
        setContentView(s)
    }

    private fun letterForm(type:String){
        currentPage = { letterForm(type) }
        selectedType=type; val s=base();title(type,"Tell us the facts. The letter does the talking.")
        val info=TextView(this).apply{text="Date fields open a calendar. Your phone's autofill can fill supported personal details.";textSize=12f;setTextColor(Color.DKGRAY);setPadding(6,0,6,12)};root.addView(info)
        inputs.clear(); addField("name","Your name","Name",1,true);addField("contact","Contact details","Email, phone or address",2,true)
        when{type.startsWith("Refund")-> {addField("business","Company / seller","Who are you writing to?");addField("item","Purchase","What did you buy?");dateField("date","Purchase date");addField("amount","Amount paid","£");addField("problem","What went wrong?","Explain clearly",4);addField("resolution","What would you like?","Refund, replacement or other outcome",2)}
            type.startsWith("Faulty")-> {addField("business","Seller / company","Name");addField("item","Product","What is faulty?");dateField("date","Purchase date");addField("problem","What is wrong?","Describe the fault",4);addField("resolution","Preferred resolution","Repair, replacement or refund",2)}
            type.startsWith("Late")-> {addField("business","Seller / delivery company","Name");addField("item","Order","What was ordered?");dateField("date","Expected delivery");addField("problem","What happened?","Delayed, missing, marked delivered, etc.",4);addField("resolution","What do you want?","Delivery, refund or investigation",2)}
            type.startsWith("Cancel")-> {addField("business","Company","Name");addField("service","Service / subscription","What are you cancelling?");addField("problem","Relevant details","Account or order details",4)}
            type.startsWith("Landlord")-> {addField("business","Landlord / agent","Name");addField("property","Property","General description");addField("problem","What is the issue?","Describe it and when it started",4);addField("resolution","What do you want?","Repair, inspection or response",2)}
            type.startsWith("Workplace")-> {addField("business","Employer / manager","Name");addField("problem","What happened?","Describe the workplace issue",4);addField("resolution","Desired outcome","Investigation, meeting or correction",2)}
            type.startsWith("Charge")-> {addField("business","Bank / merchant","Name");dateField("date","Payment date");addField("amount","Amount","£");addField("problem","Why are you disputing it?","Explain what happened",4);addField("resolution","What do you want?","Refund, reversal or investigation",2)}
            else->{addField("business","Who are you writing to?","Company, organisation or person");addField("problem","What happened?","Explain the situation clearly",5);addField("resolution","What outcome do you want?","What would resolve this?",2)}}
        button("Create my letter",{generate()},true); result=EditText(this).apply{hint="Your letter will appear here. You can edit it.";minLines=14;gravity=Gravity.TOP;textSize=15f;setTextColor(Color.DKGRAY);setPadding(18,18,18,18);background=GradientDrawable().apply{cornerRadius=18f;setColor(Color.WHITE);setStroke(2,lilac)} };root.addView(result,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,8)});button("Copy",{copyResult()});button("Share",{shareResult()});button("Save / update",{saveLetter()});button("Export PDF",{exportPdf()});backButton();setContentView(s)
    }
    private fun addField(key:String,label:String,hint:String,lines:Int=2,autofill:Boolean=false){root.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(deepPurple);setPadding(6,9,6,2)});val e=EditText(this).apply{this.hint=hint;minLines=lines;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;setText(prefs.getString(key,""));if(autofill){when(key){"name"->setAutofillHints("name");"contact"->setAutofillHints("emailAddress","phone","postalAddress")}}};root.addView(e);inputs[key]=e}
    private fun dateField(key:String,label:String){root.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(deepPurple);setPadding(6,9,6,2)});val e=EditText(this).apply{hint="Tap to choose date";isFocusable=false;setText(prefs.getString(key,""));setOnClickListener{val c=Calendar.getInstance();DatePickerDialog(this@MainActivity,{_,y,m,d->setText(String.format(Locale.getDefault(),"%02d/%02d/%04d",d,m+1,y))},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}};root.addView(e);inputs[key]=e}
    private fun v(k:String)=inputs[k]?.text?.toString()?.trim().orEmpty()
    private fun generate(){val r=result?:return;val name=v("name").ifBlank{"[Your name]"};val business=v("business").ifBlank{"[Company / organisation]"};val problem=v("problem");if(problem.isBlank()){toast("Please describe what happened.");return};val resolution=v("resolution").ifBlank{"a clear written response and the next steps"};val text="Dear Sir/Madam,\n\nI am writing regarding $selectedType.\n\n${if(v("item").isNotBlank())"Item: ${v("item")}\n" else ""}${if(v("date").isNotBlank())"Date: ${v("date")}\n" else ""}${if(v("amount").isNotBlank())"Amount: ${v("amount")}\n" else ""}\nThe situation is:\n$problem\n\nI would like: \n$resolution\n\nPlease review this matter and confirm in writing what action you will take and the expected timescale.\n\nYours faithfully,\n\n$name";r.setText(text);r.setSelection(0)}
    private fun saveLetter(){val r=result?:return;if(r.text.isBlank()){toast("Create a letter first.");return};val now=SimpleDateFormat("dd MMM yyyy HH:mm",Locale.getDefault()).format(Date());inputs.forEach{(k,e)->prefs.edit().putString(k,e.text.toString()).apply()};val old=prefs.getString("history","")?:"";val entry="[$now] $selectedType\n${r.text}\n---END---\n";prefs.edit().putString("history",(entry+old).take(30000)).apply();toast("Saved — $now")}
    private fun myLetters(){
        currentPage = { myLetters() }
        val raw=prefs.getString("history","")?:"";val s=base();title("My Letters","Your projects, with the last edit time saved.");if(raw.isBlank())root.addView(TextView(this).apply{text="Nothing saved yet. Create a letter and tap Save / update.";textSize=16f;setPadding(6,20,6,20)});else raw.split("\n---END---\n").filter{it.isNotBlank()}.forEachIndexed{idx,e->val lines=e.lines();val stamp=lines.firstOrNull().orEmpty();val type=lines.drop(1).firstOrNull().orEmpty();card(type,stamp){AlertDialog.Builder(this).setTitle(type).setMessage(e.substringAfter("\n")).setPositiveButton("Load"){_,_->letterForm(type)}.setNegativeButton("Delete"){_,_->toast("Delete from My Letters coming in the next build.")}.show()}};navButton("+ New letter",{directory()},true);backButton();setContentView(s)}
    private fun deleteHistoryEntry(index:Int){
        val raw=prefs.getString("history","")?:""
        val entries=raw.split("\n---END---\n").filter{it.isNotBlank()}.toMutableList()
        if(index in entries.indices){ entries.removeAt(index); prefs.edit().putString("history",entries.joinToString("\n---END---\n")).apply(); toast("Letter deleted") }
        myLetters()
    }
    private fun aboutPrivacy(){
        currentPage = { aboutPrivacy() }
        val s=base(); title("About & privacy","Claim It is designed to keep ordinary correspondence simple and local-first.")
        listOf(
            "Your saved letter history is stored locally on this device.",
            "Claim It does not require an account to create letters.",
            "The app does not send your letter contents to a Claim It server or AI API.",
            "Sharing and PDF export happen only when you choose those actions.",
            "Templates are general correspondence tools, not professional legal advice."
        ).forEach{root.addView(TextView(this).apply{text="• $it";textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,10,6,10)})}
        backButton(); setContentView(s)
    }
    private fun support(){
        currentPage = { support() }
        val s=base();title("Assistance & guidance","Clear, simple instructions — no guesswork.");listOf("Your name — usually the name on your account or correspondence.","Company — check the invoice, receipt, website or previous emails.","Date — check your receipt, order history, bank statement or appointment confirmation.","Amount — check your receipt or bank/card statement.","Location — use the address shown on the relevant bill, booking or contract.","Problem — stick to what happened, when it happened and what evidence you have.","Outcome — say what you want the company to do to put things right.").forEach{root.addView(TextView(this).apply{text="• $it";textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,10,6,10)})};root.addView(TextView(this).apply{text="Templates are designed as general correspondence and should be checked for your circumstances. Claim It does not provide professional legal advice.";textSize=12f;setTextColor(Color.GRAY);setPadding(6,18,6,10)});backButton();setContentView(s)}
    private fun worthIt(){
        currentPage = { worthIt() }
        val s=base();title("WORTH-IT","A friendly reviews section built around useful experiences.");root.addView(TextView(this).apply{text="Coming next: product and service reviews, quick pros/cons, and a simple 'Was it worth it?' verdict.";textSize=16f;setTextColor(Color.DKGRAY);setPadding(6,12,6,24)});backButton();setContentView(s)}
    private fun copyResult(){val r=result?:return;getSystemService(CLIPBOARD_SERVICE).let{(it as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Claim It",r.text))};toast("Copied")}
    private fun shareResult(){val r=result?:return;if(r.text.isBlank())return toast("Create a letter first.");startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,r.text)},"Share letter"))}
    private fun exportPdf(){val r=result?:return;if(r.text.isBlank())return toast("Create a letter first.");if(android.os.Build.VERSION.SDK_INT < 29)return toast("PDF export needs Android 10 or newer.");val doc=android.graphics.pdf.PdfDocument();val info=android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create();val p=doc.startPage(info);val paint=Paint().apply{textSize=12f;color=Color.DKGRAY};var y=55f;r.text.toString().lines().forEach{line->p.canvas.drawText(line.take(90),45f,y,paint);y+=18;if(y>800f)return@forEach};doc.finishPage(p);val name="ClaimIt_${System.currentTimeMillis()}.pdf";val cv=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,"Download/Claim It")};val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv)?:return toast("Couldn't create PDF");val output = contentResolver.openOutputStream(uri)
            ?: return toast("Couldn't open PDF output")
        output.use { doc.writeTo(it) }
        doc.close()
        toast("PDF saved to Downloads/Claim It")}
    private fun toast(t:String){Toast.makeText(this,t,Toast.LENGTH_SHORT).show()}

    class WheelView(
        c: Context,
        private val items: List<String>,
        private val pick: (String) -> Unit
    ) : View(c) {
        private val host: MainActivity? = c as? MainActivity
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val colors = intArrayOf(
            Color.rgb(255, 52, 117), Color.rgb(255, 166, 36), Color.rgb(255, 224, 54),
            Color.rgb(66, 222, 137), Color.rgb(34, 204, 216), Color.rgb(62, 126, 255),
            Color.rgb(122, 75, 250), Color.rgb(198, 58, 232), Color.rgb(255, 75, 181),
            Color.rgb(255, 101, 61), Color.rgb(102, 220, 74), Color.rgb(29, 190, 178),
            Color.rgb(47, 157, 241), Color.rgb(155, 78, 232), Color.rgb(244, 67, 111)
        )
        private var angle = 0f
        private var lastTouchAngle = 0f
        private var velocity = 0f
        private var animator: ValueAnimator? = null
        private var selectedIndex = 0
        private var lastTickIndex = 0
        private var dragging = false
        private val rng = Random()

        init {
            isClickable = true
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = min(width, height) * 0.48f
            val inner = r * 0.20f
            rect.set(cx-r, cy-r, cx+r, cy+r)

            // Pinball-style outer glow and chrome rings.
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(25, 10, 35)
            canvas.drawCircle(cx, cy, r + 18f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 11f
            paint.color = Color.rgb(205, 196, 213)
            canvas.drawCircle(cx, cy, r + 8f, paint)
            paint.strokeWidth = 4f
            paint.color = Color.rgb(75, 56, 84)
            canvas.drawCircle(cx, cy, r + 14f, paint)

            val sweep = 360f / items.size
            for (i in items.indices) {
                val start = -90f + i * sweep + angle
                paint.style = Paint.Style.FILL
                paint.color = colors[i % colors.size]
                canvas.drawArc(rect, start + 0.8f, sweep - 1.6f, true, paint)

                // Segment highlight for a glossy arcade-wheel look.
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = Color.argb(110, 255, 255, 255)
                canvas.drawArc(rect, start + 2.5f, sweep * 0.45f, false, paint)

                // Labels run radially: reading from the hub outwards.
                val midDeg = start + sweep / 2f
                val mid = Math.toRadians(midDeg.toDouble())
                val startRadius = r * 0.29f
                val textX = cx + cos(mid) * startRadius
                val textY = cy + sin(mid) * startRadius
                val maxWidth = r * 0.61f
                canvas.save()
                canvas.rotate(midDeg, textX.toFloat(), textY.toFloat())
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.LEFT
                paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                paint.letterSpacing = 0.015f
                // Large, deliberately readable wheel lettering.
                // The previous build used roughly 9.5–13px here; this build
                // makes the labels substantially larger while still wrapping
                // long category names inside their segment.
                paint.textScaleX = 0.82f
                paint.textSize = when {
                    items[i].length > 31 -> 19f
                    items[i].length > 25 -> 20.5f
                    items[i].length > 20 -> 22f
                    else -> 24f
                }
                drawRadialLabel(canvas, items[i], textX.toFloat(), textY.toFloat(), maxWidth)
                paint.textScaleX = 1f
                canvas.restore()
            }

            // Inner decorative ring.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            paint.color = Color.rgb(255, 235, 110)
            canvas.drawCircle(cx, cy, inner + 13f, paint)
            paint.strokeWidth = 3f
            paint.color = Color.rgb(255, 72, 132)
            canvas.drawCircle(cx, cy, inner + 20f, paint)

            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(46, 19, 58)
            canvas.drawCircle(cx, cy, inner + 6f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.WHITE
            canvas.drawCircle(cx, cy, inner + 6f, paint)
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            paint.textSize = 15f
            paint.color = Color.WHITE
            canvas.drawText("CLAIM IT", cx, cy + 5f, paint)

            // Pinball bulbs around the rim.
            for (i in 0 until 32) {
                val a = Math.toRadians((-90f + i * (360f / 32f) + angle * 0.12f).toDouble())
                val br = r + 8f
                val bx = cx + cos(a) * br
                val by = cy + sin(a) * br
                paint.style = Paint.Style.FILL
                paint.color = if (i % 3 == 0) Color.rgb(255, 245, 150) else Color.WHITE
                canvas.drawCircle(bx.toFloat(), by.toFloat(), 3.1f, paint)
            }

            // A proper arcade-style chrome pointer with a lit red tip.
            val pointer = Path()
            pointer.moveTo(cx, 5f)
            pointer.lineTo(cx - 24f, 39f)
            pointer.lineTo(cx + 24f, 39f)
            pointer.close()
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(225, 221, 231)
            canvas.drawPath(pointer, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.rgb(65, 45, 72)
            canvas.drawPath(pointer, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(255, 52, 117)
            canvas.drawCircle(cx, 13f, 5f, paint)
        }

        private fun drawRadialLabel(canvas: Canvas, text: String, x: Float, y: Float, maxWidth: Float) {
            val words = text.split(" ")
            var line = ""
            val lines = mutableListOf<String>()
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                    lines.add(line)
                    line = word
                } else {
                    line = candidate
                }
            }
            if (line.isNotEmpty()) lines.add(line)
            val lineH = paint.textSize * 1.05f
            lines.forEachIndexed { idx, ln ->
                canvas.drawText(ln, x, y + idx * lineH, paint)
            }
        }

        private fun touchAngle(x: Float, y: Float): Float {
            val cx = width / 2f
            val cy = height / 2f
            return Math.toDegrees(atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat()
        }

        private fun indexForAngle(a: Float): Int {
            val sweep = 360f / items.size
            return ((round((-a) / sweep).toInt() % items.size) + items.size) % items.size
        }

        private fun maybeTick() {
            val idx = indexForAngle(angle)
            if (idx != lastTickIndex) {
                lastTickIndex = idx
                host?.playWheelTick()
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animator?.cancel()
                    animator = null
                    dragging = true
                    lastTouchAngle = touchAngle(e.x, e.y)
                    velocity = 0f
                    lastTickIndex = indexForAngle(angle)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val now = touchAngle(e.x, e.y)
                    var d = now - lastTouchAngle
                    if (d > 180f) d -= 360f
                    if (d < -180f) d += 360f
                    angle += d
                    velocity = velocity * 0.55f + d * 0.45f
                    lastTouchAngle = now
                    maybeTick()
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    if (abs(velocity) > 1.1f) fling(velocity) else snapToNearest()
                    return true
                }
            }
            return true
        }

        private fun fling(v: Float) {
            val direction = if (v >= 0f) 1f else -1f
            val extraTurns = 2.2f + rng.nextFloat() * 2.6f
            val target = angle + direction * (extraTurns * 360f + abs(v) * 20f)
            animateTo(target, 1550L + min(850L, (abs(v) * 55f).toLong()))
        }

        private fun snapToNearest() {
            val sweep = 360f / items.size
            val target = round(angle / sweep) * sweep
            animateTo(target, 420L)
        }

        private fun animateTo(target: Float, duration: Long) {
            animator?.cancel()
            val from = angle
            animator = ValueAnimator.ofFloat(from, target).apply {
                this.duration = duration
                interpolator = DecelerateInterpolator(2.25f)
                addUpdateListener {
                    angle = it.animatedValue as Float
                    maybeTick()
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        val sweep = 360f / items.size
                        angle = round(angle / sweep) * sweep
                        selectedIndex = indexForAngle(angle)
                        lastTickIndex = selectedIndex
                        invalidate()
                        host?.playWheelStop()
                        pick(items[selectedIndex])
                    }
                })
                start()
            }
        }
    }

}
