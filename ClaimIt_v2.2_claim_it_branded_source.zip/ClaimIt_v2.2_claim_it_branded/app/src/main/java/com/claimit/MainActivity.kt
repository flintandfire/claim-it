package com.claimit

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.speech.tts.TextToSpeech
import android.media.AudioAttributes
import android.media.SoundPool
import android.animation.ValueAnimator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {
    private var tts: TextToSpeech? = null
    private var soundPool: SoundPool? = null
    private var wheelTickSound = 0
    private var wheelStopSound = 0
    private val pink = Color.rgb(250, 185, 221)
    private val purple = Color.rgb(170, 91, 196)
    private val deepPurple = Color.rgb(58, 28, 78)
    private val lilac = Color.rgb(224, 200, 242)
    private val cream = Color.rgb(255, 250, 253)
    private val dark = Color.rgb(15, 8, 27)
    private val white = Color.WHITE
    private var screenNo = 0
    private val prefs by lazy { getSharedPreferences("claimit", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val inputs = mutableMapOf<String, EditText>()
    private var selectedType = ""
    private var result: EditText? = null
    private val pageStack = ArrayDeque<() -> Unit>()
    private var currentPage: (() -> Unit)? = null
    private var selectedLettersView: LinearLayout? = null
    private val letterChoices = mapOf(
        "Refund / money back" to listOf("Ask for a full refund","Ask for a partial refund","Refund for a returned item","Refund for a cancelled service","Refund for a duplicate payment"),
        "Faulty or damaged product" to listOf("Faulty product complaint","Request a repair","Request a replacement","Request a refund","Report damage on delivery"),
        "Late or missing delivery" to listOf("Late delivery complaint","Item marked delivered but missing","Missing parcel investigation","Request a delivery refund","Delivery deadline complaint"),
        "Complaint about a service" to listOf("Make a formal complaint","Poor service complaint","Service not as described","Request compensation","Request a written response"),
        "Cancel a subscription or service" to listOf("Cancel a subscription","Cancel during a cooling-off period","Stop a recurring payment","Confirm cancellation in writing","Request a final bill"),
        "Landlord / housing issue" to listOf("Request a repair","Report an urgent repair","Report damp or mould","Complaint about an agent","Request an inspection"),
        "Workplace issue" to listOf("Raise a workplace concern","Make a formal grievance","Request a meeting","Challenge a workplace decision","Request written clarification"),
        "Insurance complaint" to listOf("Challenge an insurance decision","Dispute a claim outcome","Complaint about delay","Request reasons for refusal","Request a reassessment"),
        "Charge / card payment dispute" to listOf("Dispute a card payment","Challenge an unauthorised payment","Request a chargeback","Dispute a duplicate charge","Challenge an incorrect amount"),
        "Missed appointment / cancellation fee" to listOf("Challenge a cancellation fee","Explain a missed appointment","Request a fee waiver","Request a refund of a fee","Ask for a new appointment"),
        "Data / privacy request" to listOf("Request my personal data","Ask for data correction","Request deletion","Object to data use","Ask how my data is used"),
        "Warranty / guarantee request" to listOf("Make a warranty claim","Request a repair under warranty","Request a replacement under warranty","Challenge a warranty refusal","Ask for guarantee support"),
        "Appeal / reconsideration" to listOf("Request reconsideration","Appeal a decision","Challenge a penalty","Ask for a review","Provide additional evidence"),
        "Request information" to listOf("Make an information request","Ask for records","Request a copy of an agreement","Ask for reasons","Request confirmation in writing"),
        "Other" to listOf("General complaint","Request action","Ask for an explanation","Request a written response","Other correspondence")
    )
    private val categories = listOf(
        "Refund / money back", "Faulty or damaged product", "Late or missing delivery",
        "Complaint about a service", "Cancel a subscription or service", "Landlord / housing issue",
        "Workplace issue", "Insurance complaint", "Charge / card payment dispute",
        "Missed appointment / cancellation fee", "Data / privacy request", "Appeal / reconsideration"
    )

    private val allCategories = listOf(
        "Refund / money back", "Faulty or damaged product", "Late or missing delivery",
        "Complaint about a service", "Cancel a subscription or service", "Landlord / housing issue",
        "Workplace issue", "Insurance complaint", "Charge / card payment dispute",
        "Missed appointment / cancellation fee", "Data / privacy request", "Warranty / guarantee request",
        "Appeal / reconsideration", "Request information", "Other"
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        initAudio()
        splashThenHome()
    }

    private fun initAudio() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        wheelTickSound = soundPool?.load(this, com.claimit.R.raw.wheel_clack, 1) ?: 0
        wheelStopSound = soundPool?.load(this, com.claimit.R.raw.wheel_stop, 1) ?: 0
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.UK
                tts?.setPitch(0.72f)
                tts?.setSpeechRate(0.82f)
                window.decorView.postDelayed({
                    tts?.speak("Claim It", TextToSpeech.QUEUE_FLUSH, null, "claim-it-start")
                }, 450)
            }
        }
    }

    internal fun playWheelTick() {
        val id = wheelTickSound
        if (id != 0) soundPool?.play(id, 0.72f, 0.72f, 1, 0, 0.95f + Random().nextFloat() * 0.12f)
    }

    internal fun playWheelStop() {
        val id = wheelStopSound
        if (id != 0) soundPool?.play(id, 0.9f, 0.9f, 2, 0, 1.0f)
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        soundPool?.release()
        soundPool = null
        super.onDestroy()
    }

    private fun splashThenHome() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(dark)
            setPadding(18, 30, 18, 30)
        }
        val logo = ImageView(this).apply {
            setImageResource(com.claimit.R.drawable.claim_it_main_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Claim It — powered by Flint & Fire"
        }
        box.addView(logo, LinearLayout.LayoutParams(-1, 0, 1f))
        val launch = TextView(this).apply {
            text = "Letters made clearer. People made more confident."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(242, 214, 238))
            setPadding(8, 12, 8, 4)
        }
        box.addView(launch, LinearLayout.LayoutParams(-1, -2))
        setContentView(box)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        window.decorView.postDelayed({ home() }, 1500)
    }

    private fun base(): ScrollView {
        screenNo++
        val bg = when (screenNo % 3) { 1 -> white; 2 -> cream; else -> Color.rgb(249, 237, 249) }
        window.statusBarColor = deepPurple
        window.navigationBarColor = deepPurple
        val scroll=ScrollView(this)
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,28);setBackgroundColor(bg)}
        scroll.addView(root)
        return scroll
    }
    private fun title(t:String, sub:String="") { root.addView(TextView(this).apply{text=t;textSize=30f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple);setPadding(4,4,4,0)}); if(sub.isNotBlank()) root.addView(TextView(this).apply{text=sub;textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,2,6,18)}) }
    private fun button(text:String, onClick:()->Unit, filled:Boolean=false): Button {
        val b=Button(this).apply{
            this.text=text
            textSize=15f
            isAllCaps=false
            gravity=Gravity.CENTER
            minHeight=60
            minimumHeight=60
            maxLines=3
            includeFontPadding=true
            setLineSpacing(1f,1.05f)
            setOnClickListener{onClick()}
            setPadding(16,12,16,12)
        }
        b.background=GradientDrawable().apply{cornerRadius=24f;setColor(if(filled) purple else lilac)}
        b.setTextColor(if(filled)Color.WHITE else deepPurple)
        root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})
        return b
    }
    private fun navButton(text:String, onClick:()->Unit, filled:Boolean=false): Button {
        return button(text,{ currentPage?.let{pageStack.addLast(it)}; onClick() },filled)
    }
    private fun goBack(){
        if(pageStack.isNotEmpty()) pageStack.removeLast().invoke() else home()
    }
    override fun onBackPressed(){
        if(pageStack.isNotEmpty()) goBack() else super.onBackPressed()
    }
    private fun home(){
        pageStack.clear()
        currentPage = { home() }
        val s=base();title("Claim It","Letters made clearer. People made more confident.")
        card("MY LETTERS","Open saved projects and see when they were last edited."){ myLetters() }
        card("NEW LETTER","Choose what you need. The full letter directory lives here."){ directory() }
        card("ASSISTANCE & GUIDANCE","Plain-English help on what to put in each box."){ support() }
        card("CUSTOMER SUPPORT","Feedback, contact and app information."){ support() }
        card("ABOUT & PRIVACY","What Claim It does, what it stores and what it does not send anywhere."){ aboutPrivacy() }
        card("WORTH-IT","Reviews and useful product experiences — coming next."){ worthIt() }
        root.addView(TextView(this).apply{text="Advertisement";textSize=10f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,20,0,4)})
        root.addView(TextView(this).apply{text="Free to use • no account required • letters stay on your phone";textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.GRAY);setPadding(0,10,0,0)})
        setContentView(s)
    }
    private fun card(head:String, sub:String, click:()->Unit){
        val c=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(18,15,18,15)
            background=GradientDrawable().apply{cornerRadius=26f;setColor(pink)}
            setOnClickListener{currentPage?.let{pageStack.addLast(it)};click()}
        }
        c.addView(TextView(this).apply{text=head;textSize=18f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple)})
        c.addView(TextView(this).apply{text=sub;textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,3,0,0)})
        root.addView(c,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,7,0,7)})
    }
    private fun backButton(){button("‹  Back",{goBack()})}

    private fun directory(){
        currentPage = { directory() }
        val s=base()
        title("Choose your letter","Flick the wheel to spin it. Drag gently to position it exactly.")
        val wheelSize=(resources.displayMetrics.widthPixels*1.22f).toInt().coerceIn(620,900)
        val wheel=WheelView(this,categories){type->showLetterChoices(type)}
        root.addView(wheel,LinearLayout.LayoutParams(-1,wheelSize).apply{setMargins(-8,0,-8,0)})
        root.addView(TextView(this).apply{text="Stop on a subject to reveal the letters in that category.";textSize=13f;gravity=Gravity.CENTER;setTextColor(Color.DKGRAY);setPadding(6,10,6,4)})
        selectedLettersView=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,4,0,8)}
        root.addView(selectedLettersView,LinearLayout.LayoutParams(-1,-2))
        navButton("Browse all subjects",{showAllSubjects()},false)
        backButton()
        setContentView(s)
    }

    private fun showLetterChoices(type:String){
        selectedType=type
        val holder=selectedLettersView ?: return
        holder.removeAllViews()
        holder.addView(TextView(this).apply{
            text=type
            textSize=22f;typeface=Typeface.DEFAULT_BOLD;setTextColor(deepPurple);setPadding(8,12,8,6)
        })
        holder.addView(TextView(this).apply{
            text="Choose the letter you want to make:"
            textSize=14f;setTextColor(Color.DKGRAY);setPadding(8,0,8,8)
        })
        letterChoices[type].orEmpty().forEachIndexed{index,letter->
            val b=buttonView(letter,index%2==0)
            b.setOnClickListener{pageStack.addLast(currentPage ?: {directory()});letterForm(type)}
            holder.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,5,0,5)})
        }
        holder.visibility=View.VISIBLE
    }

    private fun buttonView(text:String,accent:Boolean):Button{
        return Button(this).apply{
            this.text=text;textSize=15f;isAllCaps=false;gravity=Gravity.CENTER;minHeight=58;maxLines=3
            setPadding(16,12,16,12);setTextColor(if(accent)Color.WHITE else deepPurple)
            background=GradientDrawable().apply{cornerRadius=22f;setColor(if(accent)purple else lilac)}
        }
    }

    private fun showAllSubjects(){
        val s=base();title("All subjects","Choose a subject directly, or use the spinning wheel to browse visually.")
        categories.forEach{t->navButton(t,{letterForm(t)},false)}
        backButton();setContentView(s)
    }

    private fun letterForm(type:String){
        currentPage = { letterForm(type) }
        selectedType=type; val s=base();title(type,"Tell us the facts. The letter does the talking.")
        val info=TextView(this).apply{text="Date fields open a calendar. Your phone's autofill can fill supported personal details.";textSize=12f;setTextColor(Color.DKGRAY);setPadding(6,0,6,12)};root.addView(info)
        inputs.clear(); addField("name","Your name","Name",1,true);addField("contact","Contact details","Email, phone or address",2,true)
        when{type.startsWith("Refund")-> {addField("business","Company / seller","Who are you writing to?");addField("item","Purchase","What did you buy?");dateField("date","Purchase date");addField("amount","Amount paid","£");addField("problem","What went wrong?","Explain clearly",4);addField("resolution","What would you like?","Refund, replacement or other outcome",2)}
            type.startsWith("Faulty")-> {addField("business","Seller / company","Name");addField("item","Product","What is faulty?");dateField("date","Purchase date");addField("problem","What is wrong?","Describe the fault",4);addField("resolution","Preferred resolution","Repair, replacement or refund",2)}
            type.startsWith("Late")-> {addField("business","Seller / delivery company","Name");addField("item","Order","What was ordered?");dateField("date","Expected delivery");addField("problem","What happened?","Delayed, missing, marked delivered, etc.",4);addField("resolution","What do you want?","Delivery, refund or investigation",2)}
            type.startsWith("Cancel")-> {addField("business","Company","Name");addField("service","Service / subscription","What are you cancelling?");addField("problem","Relevant details","Account or order details",4)}
            type.startsWith("Landlord")-> {addField("business","Landlord / agent","Name");addField("property","Property","General description");addField("problem","What is the issue?","Describe it and when it started",4);addField("resolution","What do you want?","Repair, inspection or response",2)}
            type.startsWith("Workplace")-> {addField("business","Employer / manager","Name");addField("problem","What happened?","Describe the workplace issue",4);addField("resolution","Desired outcome","Investigation, meeting or correction",2)}
            type.startsWith("Charge")-> {addField("business","Bank / merchant","Name");dateField("date","Payment date");addField("amount","Amount","£");addField("problem","Why are you disputing it?","Explain what happened",4);addField("resolution","What do you want?","Refund, reversal or investigation",2)}
            else->{addField("business","Who are you writing to?","Company, organisation or person");addField("problem","What happened?","Explain the situation clearly",5);addField("resolution","What outcome do you want?","What would resolve this?",2)}}
        button("Create my letter",{generate()},true); result=EditText(this).apply{hint="Your letter will appear here. You can edit it.";minLines=14;gravity=Gravity.TOP;textSize=15f;setTextColor(Color.DKGRAY);setPadding(18,18,18,18);background=GradientDrawable().apply{cornerRadius=18f;setColor(Color.WHITE);setStroke(2,lilac)} };root.addView(result,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,10,0,8)});button("Copy",{copyResult()});button("Share",{shareResult()});button("Save / update",{saveLetter()});button("Export PDF",{exportPdf()});backButton();setContentView(s)
    }
    private fun addField(key:String,label:String,hint:String,lines:Int=2,autofill:Boolean=false){root.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(deepPurple);setPadding(6,9,6,2)});val e=EditText(this).apply{this.hint=hint;minLines=lines;gravity=Gravity.TOP;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;setText(prefs.getString(key,""));if(autofill){when(key){"name"->setAutofillHints("name");"contact"->setAutofillHints("emailAddress","phone","postalAddress")}}};root.addView(e);inputs[key]=e}
    private fun dateField(key:String,label:String){root.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(deepPurple);setPadding(6,9,6,2)});val e=EditText(this).apply{hint="Tap to choose date";isFocusable=false;setText(prefs.getString(key,""));setOnClickListener{val c=Calendar.getInstance();DatePickerDialog(this@MainActivity,{_,y,m,d->setText(String.format(Locale.getDefault(),"%02d/%02d/%04d",d,m+1,y))},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}};root.addView(e);inputs[key]=e}
    private fun v(k:String)=inputs[k]?.text?.toString()?.trim().orEmpty()
    private fun generate(){val r=result?:return;val name=v("name").ifBlank{"[Your name]"};val business=v("business").ifBlank{"[Company / organisation]"};val problem=v("problem");if(problem.isBlank()){toast("Please describe what happened.");return};val resolution=v("resolution").ifBlank{"a clear written response and the next steps"};val text="Dear Sir/Madam,\n\nI am writing regarding $selectedType.\n\n${if(v("item").isNotBlank())"Item: ${v("item")}\n" else ""}${if(v("date").isNotBlank())"Date: ${v("date")}\n" else ""}${if(v("amount").isNotBlank())"Amount: ${v("amount")}\n" else ""}\nThe situation is:\n$problem\n\nI would like: \n$resolution\n\nPlease review this matter and confirm in writing what action you will take and the expected timescale.\n\nYours faithfully,\n\n$name";r.setText(text);r.setSelection(0)}
    private fun saveLetter(){val r=result?:return;if(r.text.isBlank()){toast("Create a letter first.");return};val now=SimpleDateFormat("dd MMM yyyy HH:mm",Locale.getDefault()).format(Date());inputs.forEach{(k,e)->prefs.edit().putString(k,e.text.toString()).apply()};val old=prefs.getString("history","")?:"";val entry="[$now] $selectedType\n${r.text}\n---END---\n";prefs.edit().putString("history",(entry+old).take(30000)).apply();toast("Saved — $now")}
    private fun myLetters(){
        currentPage = { myLetters() }
        val raw=prefs.getString("history","")?:"";val s=base();title("My Letters","Your projects, with the last edit time saved.");if(raw.isBlank())root.addView(TextView(this).apply{text="Nothing saved yet. Create a letter and tap Save / update.";textSize=16f;setPadding(6,20,6,20)});else raw.split("\n---END---\n").filter{it.isNotBlank()}.forEachIndexed{idx,e->val lines=e.lines();val stamp=lines.firstOrNull().orEmpty();val type=lines.drop(1).firstOrNull().orEmpty();card(type,stamp){AlertDialog.Builder(this).setTitle(type).setMessage(e.substringAfter("\n")).setPositiveButton("Load"){_,_->letterForm(type)}.setNegativeButton("Delete"){_,_->toast("Delete from My Letters coming in the next build.")}.show()}};navButton("+ New letter",{directory()},true);backButton();setContentView(s)}
    private fun deleteHistoryEntry(index:Int){
        val raw=prefs.getString("history","")?:""
        val entries=raw.split("\n---END---\n").filter{it.isNotBlank()}.toMutableList()
        if(index in entries.indices){ entries.removeAt(index); prefs.edit().putString("history",entries.joinToString("\n---END---\n")).apply(); toast("Letter deleted") }
        myLetters()
    }
    private fun aboutPrivacy(){
        currentPage = { aboutPrivacy() }
        val s=base(); title("About & privacy","Claim It is designed to keep ordinary correspondence simple and local-first.")
        listOf(
            "Your saved letter history is stored locally on this device.",
            "Claim It does not require an account to create letters.",
            "The app does not send your letter contents to a Claim It server or AI API.",
            "Sharing and PDF export happen only when you choose those actions.",
            "Templates are general correspondence tools, not professional legal advice."
        ).forEach{root.addView(TextView(this).apply{text="• $it";textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,10,6,10)})}
        backButton(); setContentView(s)
    }
    private fun support(){
        currentPage = { support() }
        val s=base();title("Assistance & guidance","Clear, simple instructions — no guesswork.");listOf("Your name — usually the name on your account or correspondence.","Company — check the invoice, receipt, website or previous emails.","Date — check your receipt, order history, bank statement or appointment confirmation.","Amount — check your receipt or bank/card statement.","Location — use the address shown on the relevant bill, booking or contract.","Problem — stick to what happened, when it happened and what evidence you have.","Outcome — say what you want the company to do to put things right.").forEach{root.addView(TextView(this).apply{text="• $it";textSize=15f;setTextColor(Color.DKGRAY);setPadding(6,10,6,10)})};root.addView(TextView(this).apply{text="Templates are designed as general correspondence and should be checked for your circumstances. Claim It does not provide professional legal advice.";textSize=12f;setTextColor(Color.GRAY);setPadding(6,18,6,10)});backButton();setContentView(s)}
    private fun worthIt(){
        currentPage = { worthIt() }
        val s=base();title("WORTH-IT","A friendly reviews section built around useful experiences.");root.addView(TextView(this).apply{text="Coming next: product and service reviews, quick pros/cons, and a simple 'Was it worth it?' verdict.";textSize=16f;setTextColor(Color.DKGRAY);setPadding(6,12,6,24)});backButton();setContentView(s)}
    private fun copyResult(){val r=result?:return;getSystemService(CLIPBOARD_SERVICE).let{(it as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("Claim It",r.text))};toast("Copied")}
    private fun shareResult(){val r=result?:return;if(r.text.isBlank())return toast("Create a letter first.");startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,r.text)},"Share letter"))}
    private fun exportPdf(){val r=result?:return;if(r.text.isBlank())return toast("Create a letter first.");if(android.os.Build.VERSION.SDK_INT < 29)return toast("PDF export needs Android 10 or newer.");val doc=android.graphics.pdf.PdfDocument();val info=android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create();val p=doc.startPage(info);val paint=Paint().apply{textSize=12f;color=Color.DKGRAY};var y=55f;r.text.toString().lines().forEach{line->p.canvas.drawText(line.take(90),45f,y,paint);y+=18;if(y>800f)return@forEach};doc.finishPage(p);val name="ClaimIt_${System.currentTimeMillis()}.pdf";val cv=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,"Download/Claim It")};val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv)?:return toast("Couldn't create PDF");val output = contentResolver.openOutputStream(uri)
            ?: return toast("Couldn't open PDF output")
        output.use { doc.writeTo(it) }
        doc.close()
        toast("PDF saved to Downloads/Claim It")}
    private fun toast(t:String){Toast.makeText(this,t,Toast.LENGTH_SHORT).show()}

    class WheelView(
        c: Context,
        private val items: List<String>,
        private val pick: (String) -> Unit
    ) : View(c) {
        private val host: MainActivity? = c as? MainActivity
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val colors = intArrayOf(
            Color.rgb(245, 48, 104), Color.rgb(255, 145, 32), Color.rgb(255, 213, 48),
            Color.rgb(73, 213, 119), Color.rgb(30, 196, 211), Color.rgb(45, 119, 239),
            Color.rgb(111, 70, 224), Color.rgb(191, 55, 220), Color.rgb(242, 63, 163),
            Color.rgb(255, 91, 55), Color.rgb(81, 203, 74), Color.rgb(28, 177, 171)
        )
        private var angle = 0f
        private var lastTouchAngle = 0f
        private var velocity = 0f
        private var animator: ValueAnimator? = null
        private var selectedIndex = 0
        private var lastTickIndex = 0
        private var lastMoveTime = 0L
        private val rng = Random()

        init {
            isClickable = true
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val r = min(width, height) * 0.485f
            val inner = r * 0.19f
            rect.set(cx-r, cy-r, cx+r, cy+r)

            // Deep arcade backdrop and bright outer rings.
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(30, 10, 43)
            canvas.drawCircle(cx, cy, r + 19f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 14f
            paint.color = Color.rgb(255, 218, 76)
            canvas.drawCircle(cx, cy, r + 10f, paint)
            paint.strokeWidth = 7f
            paint.color = Color.rgb(236, 65, 141)
            canvas.drawCircle(cx, cy, r + 16f, paint)
            paint.strokeWidth = 3f
            paint.color = Color.WHITE
            canvas.drawCircle(cx, cy, r + 22f, paint)

            val sweep = 360f / items.size
            for (i in items.indices) {
                val start = -90f + i * sweep + angle
                val colour = colors[i % colors.size]
                paint.style = Paint.Style.FILL
                paint.color = colour
                canvas.drawArc(rect, start + 0.9f, sweep - 1.8f, true, paint)

                // Glossy highlight along the leading edge of every slice.
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                paint.color = Color.argb(95, 255, 255, 255)
                canvas.drawArc(rect, start + 2f, sweep * 0.62f, false, paint)

                // Radial labels: deliberately laid out from the hub towards the rim.
                val midDeg = start + sweep / 2f
                val rad = Math.toRadians(midDeg.toDouble())
                val labelRadius = r * 0.285f
                val x = cx + cos(rad) * labelRadius
                val y = cy + sin(rad) * labelRadius
                val maxWidth = r * 0.64f
                canvas.save()
                canvas.rotate(midDeg, x.toFloat(), y.toFloat())
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.LEFT
                paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                paint.setShadowLayer(3f, 0f, 1.5f, Color.argb(180, 30, 10, 45))
                paint.textSize = when {
                    items[i].length > 31 -> 10f
                    items[i].length > 25 -> 11f
                    items[i].length > 20 -> 12f
                    else -> 14f
                }
                drawRadialLabel(canvas, items[i], x.toFloat(), y.toFloat(), maxWidth)
                paint.clearShadowLayer()
                canvas.restore()
            }

            // Centre hub.
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(44, 18, 60)
            canvas.drawCircle(cx, cy, inner + 15f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 6f
            paint.color = Color.rgb(255, 221, 77)
            canvas.drawCircle(cx, cy, inner + 15f, paint)
            paint.strokeWidth = 3f
            paint.color = Color.WHITE
            canvas.drawCircle(cx, cy, inner + 9f, paint)
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            paint.textSize = 17f
            paint.color = Color.WHITE
            canvas.drawText("CLAIM IT", cx, cy + 6f, paint)

            // Chasing marquee bulbs. Their phase follows the wheel so the wheel feels alive.
            for (i in 0 until 36) {
                val a = Math.toRadians((-90f + i * 10f + angle * 0.35f).toDouble())
                val br = r + 17f
                val bx = cx + cos(a) * br
                val by = cy + sin(a) * br
                paint.style = Paint.Style.FILL
                paint.color = if ((i + floor(angle / 12f).toInt()) % 3 == 0)
                    Color.rgb(255, 235, 88) else Color.WHITE
                canvas.drawCircle(bx.toFloat(), by.toFloat(), 3.4f, paint)
            }

            // Right-hand ticker. It changes to the colour of the slice currently under it.
            val pointerX = width - 13f
            val pointerY = cy
            val pointerColour = colors[selectedIndex % colors.size]
            val pointer = Path().apply {
                moveTo(pointerX, pointerY)
                lineTo(pointerX - 45f, pointerY - 27f)
                lineTo(pointerX - 45f, pointerY + 27f)
                close()
            }
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(35, 18, 46)
            canvas.drawPath(pointer, paint)
            val litPointer = Path().apply {
                moveTo(pointerX - 2f, pointerY)
                lineTo(pointerX - 39f, pointerY - 20f)
                lineTo(pointerX - 39f, pointerY + 20f)
                close()
            }
            paint.color = pointerColour
            canvas.drawPath(litPointer, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.WHITE
            canvas.drawPath(pointer, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            canvas.drawCircle(pointerX - 12f, pointerY, 5f, paint)
        }

        private fun drawRadialLabel(canvas: Canvas, text: String, x: Float, y: Float, maxWidth: Float) {
            val words = text.split(" ")
            var line = ""
            val lines = mutableListOf<String>()
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                    lines.add(line)
                    line = word
                } else line = candidate
            }
            if (line.isNotEmpty()) lines.add(line)
            val lineH = paint.textSize * 1.05f
            lines.forEachIndexed { idx, ln -> canvas.drawText(ln, x, y + idx * lineH, paint) }
        }

        private fun touchAngle(x: Float, y: Float): Float {
            val cx = width / 2f
            val cy = height / 2f
            return Math.toDegrees(atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat()
        }

        private fun indexForAngle(a: Float): Int {
            val sweep = 360f / items.size
            return ((floor((-a + sweep / 2f) / sweep).toInt() % items.size) + items.size) % items.size
        }

        private fun maybeTick() {
            val idx = indexForAngle(angle)
            if (idx != lastTickIndex) {
                lastTickIndex = idx
                selectedIndex = idx
                host?.playWheelTick()
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animator?.cancel()
                    animator = null
                    lastTouchAngle = touchAngle(e.x, e.y)
                    velocity = 0f
                    lastMoveTime = System.currentTimeMillis()
                    lastTickIndex = indexForAngle(angle)
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val now = touchAngle(e.x, e.y)
                    var d = now - lastTouchAngle
                    if (d > 180f) d -= 360f
                    if (d < -180f) d += 360f
                    val t = System.currentTimeMillis()
                    val dt = max(1L, t - lastMoveTime)
                    val instant = d / dt.toFloat() * 16f
                    angle += d
                    velocity = velocity * 0.70f + instant * 0.30f
                    lastTouchAngle = now
                    lastMoveTime = t
                    maybeTick()
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    if (abs(velocity) > 0.35f) fling(velocity) else snapToNearest()
                    return true
                }
            }
            return true
        }

        private fun fling(v: Float) {
            val direction = if (v >= 0f) 1f else -1f
            val speed = abs(v).coerceIn(1.0f, 16f)
            val turns = 3.0f + rng.nextFloat() * 3.5f
            val target = angle + direction * (turns * 360f + speed * 28f)
            animateTo(target, (2100L + speed * 95L).toLong())
        }

        private fun snapToNearest() {
            val sweep = 360f / items.size
            animateTo(round(angle / sweep) * sweep, 380L)
        }

        private fun animateTo(target: Float, duration: Long) {
            animator?.cancel()
            val from = angle
            animator = ValueAnimator.ofFloat(from, target).apply {
                this.duration = duration.coerceIn(380L, 3200L)
                interpolator = android.view.animation.PathInterpolator(0.12f, 0.75f, 0.16f, 1.0f)
                addUpdateListener {
                    angle = it.animatedValue as Float
                    selectedIndex = indexForAngle(angle)
                    maybeTick()
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        val sweep = 360f / items.size
                        angle = round(angle / sweep) * sweep
                        selectedIndex = indexForAngle(angle)
                        lastTickIndex = selectedIndex
                        invalidate()
                        host?.playWheelStop()
                        pick(items[selectedIndex])
                    }
                })
                start()
            }
        }
    }

}
