package com.claimit;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.content.res.Resources;
import android.os.SystemClock;
import android.view.VelocityTracker;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setNavigationBarColor(Color.rgb(7,3,15));
        setContentView(new WheelView(this));
    }

    static class WheelView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap bg;
        float wheelAngle = 0f;
        float lastTouchAngle;
        float angularVelocity = 0f;
        float lastMoveTime;
        boolean dragging = false;
        boolean spinning = false;
        int selected = 0;
        final String[] cats = {
            "Make a formal complaint","Poor service complaint","Service not as described",
            "Request compensation","Request a written response","Warranty / guarantee request",
            "Landlord / contract issue","Workplace complaint","Refund or chargeback",
            "Billing or overcharge","Account / money issue","Poor customer service",
            "Faulty or damaged product","Delayed or missed refund"
        };
        final int[] colors = {
            0xffff2d55,0xff00a9c7,0xffff315f,0xff08a7bf,0xffff315f,0xff00a9c7,
            0xffff8a00,0xffff2d55,0xff00a9a7,0xff00a9c7,0xff36c936,0xffff4c32,
            0xffd81b73,0xff7435e8
        };
        RectF wheelRect = new RectF();

        WheelView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            bg = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(
                "claimit_background","drawable",c.getPackageName()));
            text.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        }

        float cx, cy, radius;
        float pointAngle(float x,float y){ return (float)Math.atan2(y-cy,x-cx); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            // Full pinball-style backdrop.
            if(bg!=null) c.drawBitmap(bg,null,new Rect(0,0,w,h),p);
            else c.drawColor(Color.rgb(5,2,12));

            cx=w/2f; cy=h*0.285f; radius=Math.min(w*0.445f,h*0.265f);
            drawHeader(c,w);
            drawWheel(c);
            drawLetters(c,w,h);
            drawNav(c,w,h);
        }

        void drawHeader(Canvas c,int w){
            text.setTextAlign(Paint.Align.CENTER);
            text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
            text.setTextSize(sp(33)); text.setColor(Color.WHITE);
            p.setShadowLayer(sp(12),0,0,0xffff1d91);
            c.drawText("CHOOSE YOUR LETTER",w/2f,sp(52),text);
            p.clearShadowLayer();
            text.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
            text.setTextSize(sp(14)); text.setColor(0xffffe7f4);
            c.drawText("Flick the wheel to spin it  •  Drag gently to position it",w/2f,sp(78),text);
        }

        void drawWheel(Canvas c){
            // Outer neon arch/rim.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(5));
            p.setColor(0xffffb52d); p.setShadowLayer(sp(10),0,0,0xffff237e);
            c.drawCircle(cx,cy,radius+sp(8),p);
            p.clearShadowLayer(); p.setStrokeWidth(sp(2)); p.setColor(0xff00eaff);
            c.drawCircle(cx,cy,radius+sp(16),p);

            float sweep=360f/cats.length;
            for(int i=0;i<cats.length;i++){
                float start=(float)Math.toDegrees(wheelAngle) + i*sweep - sweep/2f;
                p.setStyle(Paint.Style.FILL); p.setColor(colors[i%colors.length]);
                c.drawArc(cx-radius,cy-radius,cx+radius,cy+radius,start,sweep+0.8f,true,p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(2)); p.setColor(0xff160b23);
                c.drawArc(cx-radius,cy-radius,cx+radius,cy+radius,start,sweep,true,p);

                // Large radial, centre-to-edge text. Keep it upright.
                double a=Math.toRadians(start+sweep/2);
                float tx=cx+(float)Math.cos(a)*radius*0.59f;
                float ty=cy+(float)Math.sin(a)*radius*0.59f;
                c.save();
                c.rotate((float)Math.toDegrees(a),tx,ty);
                boolean flip = (Math.cos(a)<0);
                if(flip) c.rotate(180,tx,ty);
                text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
                text.setTextSize(sp(17.5f));
                text.setColor(Color.WHITE);
                text.setTextAlign(Paint.Align.CENTER);
                text.setShadowLayer(sp(3),0,sp(1),0xff111111);
                String s=shortCat(cats[i]);
                c.drawText(s,tx,ty,text);
                text.clearShadowLayer();
                c.restore();
            }
            // Centre hub.
            p.setStyle(Paint.Style.FILL); p.setColor(0xff080512); p.setShadowLayer(sp(12),0,0,0xffff267e);
            c.drawCircle(cx,cy,radius*0.20f,p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(4)); p.setColor(0xffffc52f);
            c.drawCircle(cx,cy,radius*0.20f,p);
            text.setTextAlign(Paint.Align.CENTER); text.setTextSize(sp(17)); text.setTypeface(Typeface.DEFAULT_BOLD); text.setColor(Color.WHITE);
            c.drawText("CLAIM IT",cx,cy+sp(6),text);

            // Right-hand selector arrow.
            float ax=cx+radius+sp(15), ay=cy;
            Path tri=new Path(); tri.moveTo(ax+sp(30),ay); tri.lineTo(ax,ay-sp(20)); tri.lineTo(ax,ay+sp(20)); tri.close();
            p.setStyle(Paint.Style.FILL); p.setColor(0xff00e6b8); p.setShadowLayer(sp(7),0,0,0xff00e6ff);
            c.drawPath(tri,p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(3)); p.setColor(0xffffffff); c.drawPath(tri,p);
        }

        String shortCat(String s){
            if(s.length()<=23) return s;
            if(s.equals("Warranty / guarantee request")) return "Warranty / guarantee";
            if(s.equals("Delayed or missed refund")) return "Delayed / missed refund";
            if(s.equals("Request a written response")) return "Written response";
            if(s.equals("Request compensation")) return "Compensation";
            if(s.equals("Complaint about an agent")) return "Agent complaint";
            if(s.equals("Service not as described")) return "Not as described";
            return s;
        }

        void drawLetters(Canvas c,int w,int h){
            float top=h*0.60f;
            // Neon title plaque.
            p.setStyle(Paint.Style.FILL); p.setColor(0xcc07030f); p.setShadowLayer(sp(12),0,0,0xffff217d);
            c.drawRoundRect(sp(18),top,w-sp(18),top+sp(62),sp(18),sp(18),p); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(3)); p.setColor(0xffffb52d);
            c.drawRoundRect(sp(18),top,w-sp(18),top+sp(62),sp(18),sp(18),p);
            text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD)); text.setTextSize(sp(26)); text.setColor(0xffffe26d);
            c.drawText(cats[selected],w/2f,top+sp(39),text);

            text.setTextSize(sp(14)); text.setTypeface(Typeface.DEFAULT); text.setColor(Color.WHITE);
            c.drawText("Choose the letter you want to make:",w/2f,top+sp(87),text);

            String[] letters={"Make a formal complaint","Poor service complaint","Service not as described","Request compensation","Request a written response"};
            float y=top+sp(105);
            for(int i=0;i<letters.length;i++){
                p.setStyle(Paint.Style.FILL); p.setColor(i%2==0?0xffe91e57:0xff0799b0);
                p.setShadowLayer(sp(7),0,sp(2),0xffff1c7e);
                c.drawRoundRect(sp(26),y,w-sp(26),y+sp(49),sp(18),sp(18),p); p.clearShadowLayer();
                text.setTextSize(sp(16)); text.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD)); text.setColor(Color.WHITE);
                c.drawText(letters[i],w/2f,y+sp(32),text);
                text.setTextSize(sp(24)); c.drawText("›",w-sp(52),y+sp(33),text);
                y+=sp(57);
            }
        }

        void drawNav(Canvas c,int w,int h){
            float y=h-sp(78);
            p.setStyle(Paint.Style.FILL); p.setColor(0xee05030d); c.drawRect(0,y,w,h,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sp(2)); p.setColor(0xffff278a); c.drawLine(0,y,w,y,p);
            String[] n={"⌂","◉","▤","☆","⚙"};
            String[] t={"HOME","WHEEL","LETTERS","FAVOURITES","SETTINGS"};
            for(int i=0;i<5;i++){
                float x=w*(i+.5f)/5f;
                text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.DEFAULT_BOLD);
                text.setTextSize(sp(24)); text.setColor(i==1?0xffff3d98:0xffffe7f2); c.drawText(n[i],x,y+sp(30),text);
                text.setTextSize(sp(9)); c.drawText(t[i],x,y+sp(51),text);
            }
        }

        float sp(float x){ return x*getResources().getDisplayMetrics().scaledDensity; }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            float x=e.getX(), y=e.getY();
            if(y<cy+radius+sp(35) && y>cy-radius-sp(35)){
                if(e.getAction()==MotionEvent.ACTION_DOWN){
                    dragging=true; spinning=false; angularVelocity=0;
                    lastTouchAngle=pointAngle(x,y); lastMoveTime=SystemClock.uptimeMillis();
                    return true;
                }
                if(e.getAction()==MotionEvent.ACTION_MOVE && dragging){
                    float a=pointAngle(x,y);
                    float d=a-lastTouchAngle;
                    if(d>Math.PI)d-=2*Math.PI; if(d<-Math.PI)d+=2*Math.PI;
                    wheelAngle+=d;
                    long now=SystemClock.uptimeMillis();
                    float dt=Math.max(8,now-lastMoveTime)/1000f;
                    angularVelocity=d/dt;
                    lastTouchAngle=a; lastMoveTime=now;
                    invalidate(); return true;
                }
                if(e.getAction()==MotionEvent.ACTION_UP && dragging){
                    dragging=false;
                    if(Math.abs(angularVelocity)>1.7f){ spinning=true; post(spinRunner); }
                    else { snapToSegment(); }
                    return true;
                }
            }
            return true;
        }

        void snapToSegment(){
            float sweep=(float)(2*Math.PI/cats.length);
            float deg=wheelAngle;
            float target=(float)(Math.round(deg/sweep)*sweep);
            // Animate quickly to nearest segment center.
            final float start=wheelAngle, end=target;
            final long st=SystemClock.uptimeMillis();
            post(new Runnable(){ public void run(){
                float t=Math.min(1f,(SystemClock.uptimeMillis()-st)/220f);
                float e=1-(1-t)*(1-t);
                wheelAngle=start+(end-start)*e; updateSelected(); invalidate();
                if(t<1) post(this);
            }});
        }

        final Runnable spinRunner=new Runnable(){ public void run(){
            if(dragging) return;
            wheelAngle+=angularVelocity/60f;
            angularVelocity*=0.985f;
            updateSelected(); invalidate();
            if(Math.abs(angularVelocity)>0.04f) postDelayed(this,16);
            else { angularVelocity=0; spinning=false; snapToSegment(); }
        }};

        void updateSelected(){
            float sweep=(float)(2*Math.PI/cats.length);
            // right-hand pointer angle is 0 radians. Segment i center is wheelAngle + i*sweep.
            float rel=-wheelAngle/sweep;
            int idx=Math.floorMod(Math.round(rel),cats.length);
            selected=idx;
        }
    }
}
